# Elegance EstatePay — Web Application

ASP.NET Core 9 MVC web application for the UFS QwaQwa estate payment system
(CSIQ 3784 Software Engineering Project).

## Technology

| Layer      | Technology                                        |
| ---------- | ------------------------------------------------- |
| Framework  | ASP.NET Core 9 MVC (C#, Razor views)              |
| UI         | Bootstrap 5.3 + Font Awesome 6.5 (CDN)            |
| Data       | Entity Framework Core 9 + Microsoft SQL Server    |
| Auth       | Cookie authentication, PBKDF2-SHA256 passwords    |
| Login key  | **Student / staff number** (not email)            |

## Getting started

1. Open `EleganceEstatePay.sln` in Visual Studio 2022 (17.12+) with the .NET 9 SDK.
2. `appsettings.json` is configured for `db75118.public.databaseasp.net`, database `db75118`, SQL login `db75118`, encrypted transport, and the default SQL Server port. The password is intentionally not stored in source.
3. For local development, run these commands from the web project directory and enter the tested database password when prompted (do not commit it):
   ```sh
   dotnet user-secrets set "Database:Password" "<database-password>"
   ```
   For deployment, set `Database__Password` as a platform secret/environment variable. Alternatively, supply the complete tested connection string as `ConnectionStrings__DefaultConnection`; that environment setting overrides the checked-in non-secret connection details.
4. Create the database, either:
   - run `Database/schema.sql` in SQL Server Management Studio, **or**
   - just start the app — `Program.cs` calls `EnsureCreated()` and builds the schema.
5. Run the project (F5) and open `/Setup`.
   That page creates the first Administrator (Agent Head) account and then
   permanently disables itself. **No demo data or default credentials ship with
   the system.**
6. Sign in at `/Account/Login` using the staff number and password you chose.
7. As Administrator, open **Settings** and capture the five estate services and
   their tariffs (Water, Electricity, Parking, Refuse, Rent), then add Financial
   Officers under **Financial Officers** and authorise them.

For Azure deployment, follow [`AZURE_HOSTING.md`](AZURE_HOSTING.md).

## Roles and screens

### Administrator (Agent Head)
- `Admin/Index` — Estate Overview dashboard (residents, officers, payments today, pending reviews)
- `Admin/Residents` — searchable directory: create, edit, view, suspend, delete
- `Admin/Officers` — add officers, authorise / withdraw authorisation, permissions & history
- `Admin/Reports` — monthly collections per service, on-time rate, avg. officer rating, print/PDF export
- `Admin/Settings` — estate services and tariffs

### Financial Officer
- `Officer/Index` — daily payment queue, resident count, own average rating
- `Officer/AcceptPayment/{id}` — confirm or flag a payment, with account snapshot
- `Officer/Residents` + `Officer/EditResident/{id}` — manage resident details and reset passwords
- `Officer/Reviews` — ratings and reviews from residents
- `Officer/Reports` — monthly transaction report

### Resident (student / staff)
- `Resident/Index` — My Account: balance, next due date, unread notifications, Quick Pay, recent activity
- `Resident/Pay` — individual service payment with the exact calculator amount
- `Resident/Calculator` — tariff calculations with Pay, Pay selected, and Pay all calculated options
- `Resident/BulkPay` — review and submit multiple calculated service payments
- `Resident/AddCard` — validated card entry; full card number and CVC are never stored
- `Resident/PaymentReview` — payment details and final confirmation
- `Resident/PaymentComplete` — submission receipt and payment reference
- `Resident/History` — full payment history with references
- `Resident/Notifications` — payment confirmations, reminders, officer responses
- `Resident/Rate` — star rating + comment for the officer who processed a payment
- `Resident/Profile` — personal details and linked bank account
- `Account/ChangePassword` — password change

## Project layout

```
EleganceEstatePay/
├── Controllers/        Account, Setup, Home, Admin, Officer, Resident
├── Data/               AppDbContext (EF Core)
├── Models/             Entities.cs, ViewModels.cs
├── Services/           PasswordHasher, ReferenceGenerator
├── Views/              Razor views per controller + Shared layouts
├── wwwroot/css/        site.css (design system)
├── Database/schema.sql SQL Server schema (no seed data)
└── Program.cs          DI, EF Core, cookie auth, routing
```

## Security notes

- Passwords are stored as PBKDF2-SHA256 (210 000 iterations, per-user salt).
- All state-changing POST actions are protected with anti-forgery tokens.
- Authorisation policies: `AdminOnly`, `OfficerOnly`, `ResidentOnly`.
- Financial Officers cannot sign in until the Administrator authorises them.
- Student email addresses must match `studentnumber@ufs4life.ac.za`; staff addresses must match `surname@ufs.ac.za` (e.g. `miyals@ufs.ac.za`).
- Card numbers pass a Luhn check, expiry dates cannot be in the past, and CVC is restricted to 3–4 digits.
- Full card numbers and CVC values are validated for the request and are never stored.
- Deploy behind HTTPS; the Android client should talk to the same server over
  authenticated HTTPS API endpoints and must never connect directly to SQL Server.

## Demo logins

The app seeds these accounts (and the standard service tariffs) the first time it starts:

| Role | Number | Password |
| --- | --- | --- |
| Administrator | ADMIN001 | Admin@123 |
| Financial Officer | FO1001 | Officer@123 |
| Financial Officer | FO1002 | Officer@123 |

Residents register themselves with their student / staff number. Change these passwords before any real deployment.

## JSON API (for mobile / external clients)

Bearer-token API sharing the same database and rules as the website. Sign in with `POST /api/auth/login` `{ "number": "...", "password": "..." }` → `accessToken` + `refreshToken`; send `Authorization: Bearer <accessToken>`.

| Method | Path | Who | Purpose |
| --- | --- | --- | --- |
| POST | /api/auth/login | anyone | Login by student / staff number |
| POST | /api/auth/register | anyone | Resident registration (institutional email enforced) |
| POST | /api/auth/refresh | anyone | Exchange refresh token |
| POST | /api/auth/change-password | signed in | Change password |
| GET | /api/services | anyone | Active services and tariffs |
| POST | /api/services/calculate | anyone | Units × tariff + VAT |
| GET | /api/resident/me | resident | Profile, outstanding balance |
| GET/POST | /api/resident/payments | resident | History / pay one, several (bulk) or all services — amounts saved exactly as sent |
| GET | /api/resident/notifications | resident | Notifications |
| POST | /api/resident/notifications/read | resident | Mark all read |
| GET | /api/reports/summary?from=&to= | officer, admin | Collections, pending/flagged, confirmation rate, by service and method |

Card payments (`method: "Card"`) require cardHolder, cardNumber (Luhn), expiryDate (MM/YY, not expired) and cvc (3–4 digits); card number and CVC are never stored.

## Phone layout

On phones the resident portal follows the Elegance EstatePay UI Design document (Android screens): bottom navigation (Home, Pay, Notify, Profile), card-style service picker, receipt download and profile log-out.
