using EleganceEstatePay.Data;
using EleganceEstatePay.Models;
using EleganceEstatePay.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EleganceEstatePay.Controllers;

[Authorize(Policy = "AdminOnly")]
public class AdminController : Controller
{
    private readonly AppDbContext _db;

    public AdminController(AppDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        var today = DateTime.UtcNow.Date;

        var model = new AdminDashboardViewModel
        {
            TotalResidents = await _db.Users.CountAsync(u => u.Role == UserRole.Resident),
            ActiveOfficers = await _db.Users.CountAsync(u =>
                u.Role == UserRole.FinancialOfficer && u.IsAuthorised && u.Status == AccountStatus.Active),
            PaymentsToday = await _db.Payments
                .Where(p => p.Status == PaymentStatus.Paid && p.ProcessedOn != null && p.ProcessedOn!.Value.Date == today)
                .SumAsync(p => (decimal?)p.Amount) ?? 0m,
            PendingReviews = await _db.Payments.CountAsync(p => p.Status == PaymentStatus.Pending || p.Status == PaymentStatus.Flagged),
            RecentActivity = await _db.Payments
                .Include(p => p.AppUser)
                .Include(p => p.EstateService)
                .OrderByDescending(p => p.SubmittedOn)
                .Take(10)
                .ToListAsync()
        };

        return View(model);
    }

    // ---------- Manage residents ----------

    public async Task<IActionResult> Residents(string? q)
    {
        ViewBag.Query = q;

        var query = _db.Users.Where(u => u.Role == UserRole.Resident);

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(u =>
                u.Number.Contains(term) ||
                u.FirstName.Contains(term) ||
                u.Surname.Contains(term));
        }

        return View(await query.OrderBy(u => u.Surname).ToListAsync());
    }

    [HttpGet]
    public IActionResult CreateResident() =>
        View("ResidentForm", new UserFormViewModel { Role = UserRole.Resident });

    [HttpGet]
    public async Task<IActionResult> EditResident(int id)
    {
        var user = await _db.Users.FindAsync(id);
        if (user is null) return NotFound();

        return View("ResidentForm", ToForm(user));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveResident(UserFormViewModel model)
    {
        if (model.Id == 0 && string.IsNullOrWhiteSpace(model.Password))
            ModelState.AddModelError(nameof(model.Password), "A password is required for a new account.");

        if (!ModelState.IsValid) return View("ResidentForm", model);

        var number = model.Number.Trim();
        var email = model.Email.Trim();

        if (await _db.Users.AnyAsync(u => u.Number == number && u.Id != model.Id))
        {
            ModelState.AddModelError(nameof(model.Number), "That number is already in use.");
            return View("ResidentForm", model);
        }

        if (await _db.Users.AnyAsync(u => u.Email == email && u.Id != model.Id))
        {
            ModelState.AddModelError(nameof(model.Email), "That email address is already in use.");
            return View("ResidentForm", model);
        }

        AppUser user;
        if (model.Id == 0)
        {
            user = new AppUser();
            _db.Users.Add(user);
        }
        else
        {
            var existing = await _db.Users.FindAsync(model.Id);
            if (existing is null) return NotFound();
            user = existing;
        }

        user.Number = number;
        user.FirstName = model.FirstName.Trim();
        user.Surname = model.Surname.Trim();
        user.Email = email;
        user.ContactNumber = model.ContactNumber;
        user.Role = model.Role;
        user.ResidentType = model.ResidentType;
        user.Status = model.Status;

        if (!string.IsNullOrWhiteSpace(model.Password))
            user.PasswordHash = PasswordHasher.Hash(model.Password);

        await _db.SaveChangesAsync();

        TempData["Success"] = model.Id == 0 ? "Account created." : "Account updated.";
        return RedirectToAction(user.Role == UserRole.FinancialOfficer ? nameof(Officers) : nameof(Residents));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ToggleStatus(int id)
    {
        var user = await _db.Users.FindAsync(id);
        if (user is null) return NotFound();

        user.Status = user.Status == AccountStatus.Active ? AccountStatus.Suspended : AccountStatus.Active;
        await _db.SaveChangesAsync();

        TempData["Success"] = $"{user.FullName} is now {user.Status}.";
        return RedirectToAction(user.Role == UserRole.FinancialOfficer ? nameof(Officers) : nameof(Residents));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteUser(int id)
    {
        var user = await _db.Users.FindAsync(id);
        if (user is null) return NotFound();

        _db.Users.Remove(user);
        await _db.SaveChangesAsync();

        TempData["Success"] = "Account deleted.";
        return RedirectToAction(user.Role == UserRole.FinancialOfficer ? nameof(Officers) : nameof(Residents));
    }

    public async Task<IActionResult> ViewResident(int id)
    {
        var user = await _db.Users
            .Include(u => u.Payments).ThenInclude(p => p.EstateService)
            .FirstOrDefaultAsync(u => u.Id == id);

        if (user is null) return NotFound();
        return View(user);
    }

    // ---------- Manage financial officers ----------

    public async Task<IActionResult> Officers()
    {
        var officers = await _db.Users
            .Where(u => u.Role == UserRole.FinancialOfficer)
            .OrderBy(u => u.Surname)
            .ToListAsync();

        return View(officers);
    }

    [HttpGet]
    public IActionResult CreateOfficer() =>
        View("ResidentForm", new UserFormViewModel { Role = UserRole.FinancialOfficer, ResidentType = ResidentType.Staff });

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ToggleAuthorisation(int id)
    {
        var officer = await _db.Users.FindAsync(id);
        if (officer is null || officer.Role != UserRole.FinancialOfficer) return NotFound();

        officer.IsAuthorised = !officer.IsAuthorised;
        officer.AuthorisedOn = officer.IsAuthorised ? DateTime.UtcNow : null;
        await _db.SaveChangesAsync();

        TempData["Success"] = officer.IsAuthorised
            ? $"{officer.FullName} is authorised to process payments."
            : $"{officer.FullName}'s authorisation has been withdrawn.";

        return RedirectToAction(nameof(Officers));
    }

    /// <summary>View Orders: the advice, notes and confirmations captured by financial officers.</summary>
    public async Task<IActionResult> OfficerActivity()
    {
        var payments = await _db.Payments
            .Include(p => p.AppUser)
            .Include(p => p.EstateService)
            .Include(p => p.ProcessedBy)
            .Where(p => p.ProcessedByUserId != null)
            .OrderByDescending(p => p.ProcessedOn)
            .Take(200)
            .ToListAsync();

        return View(payments);
    }

    /// <summary>All resident ratings and reviews of the financial officers.</summary>
    public async Task<IActionResult> Reviews()
    {
        var reviews = await _db.ServiceReviews
            .Include(r => r.Resident)
            .Include(r => r.Officer)
            .OrderByDescending(r => r.CreatedOn)
            .ToListAsync();

        return View("~/Views/Officer/Reviews.cshtml", reviews);
    }

    // ---------- Reports ----------

    public async Task<IActionResult> Reports(DateTime? from, DateTime? to)
    {
        var start = from?.Date ?? new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1);
        var end = (to?.Date ?? DateTime.UtcNow.Date).AddDays(1);

        var payments = await _db.Payments
            .Include(p => p.EstateService)
            .Where(p => p.SubmittedOn >= start && p.SubmittedOn < end)
            .ToListAsync();

        var paid = payments.Where(p => p.Status == PaymentStatus.Paid).ToList();

        var total = paid.Sum(p => p.Amount);

        var byService = paid
            .GroupBy(p => p.EstateService!.Name)
            .Select(g => new ReportsViewModel.ServiceTotal
            {
                Service = g.Key,
                Total = g.Sum(p => p.Amount),
                Percentage = total == 0 ? 0 : (double)(g.Sum(p => p.Amount) / total) * 100
            })
            .OrderByDescending(s => s.Total)
            .ToList();

        var byMethod = paid.GroupBy(p => p.Method).Select(g => new ReportsViewModel.ServiceTotal
        {
            Service = g.Key,
            Total = g.Sum(p => p.Amount),
            Percentage = total == 0 ? 0 : (double)(g.Sum(p => p.Amount) / total) * 100
        }).OrderByDescending(x => x.Total).ToList();

        var submitted = payments.Count;
        var confirmed = paid.Count;

        var model = new ReportsViewModel
        {
            TotalCollected = total,
            PendingValue = payments.Where(p => p.Status == PaymentStatus.Pending).Sum(p => p.Amount),
            FlaggedValue = payments.Where(p => p.Status == PaymentStatus.Flagged).Sum(p => p.Amount),
            TransactionCount = submitted,
            ConfirmedCount = confirmed,
            PendingCount = payments.Count(p => p.Status == PaymentStatus.Pending),
            FlaggedCount = payments.Count(p => p.Status == PaymentStatus.Flagged),
            From = start,
            To = end.AddDays(-1),
            CollectionsByService = byService,
            CollectionsByMethod = byMethod,
            OnTimeRate = submitted == 0 ? 0 : (double)confirmed / submitted * 100,
            AverageOfficerRating = await _db.ServiceReviews.AnyAsync()
                ? await _db.ServiceReviews.AverageAsync(r => (double)r.Stars)
                : 0
        };

        return View(model);
    }

    // ---------- Settings: service tariffs ----------

    public async Task<IActionResult> Settings() =>
        View(await _db.EstateServices.OrderBy(s => s.Name).ToListAsync());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SaveService(EstateService model)
    {
        if (!ModelState.IsValid)
        {
            TempData["Error"] = "Please provide a service name and tariff.";
            return RedirectToAction(nameof(Settings));
        }

        if (model.Id == 0)
        {
            _db.EstateServices.Add(model);
        }
        else
        {
            var existing = await _db.EstateServices.FindAsync(model.Id);
            if (existing is null) return NotFound();

            existing.Name = model.Name;
            existing.Description = model.Description;
            existing.Tariff = model.Tariff;
            existing.BillingPeriod = model.BillingPeriod;
            existing.IconClass = model.IconClass;
            existing.IsActive = model.IsActive;
        }

        await _db.SaveChangesAsync();
        TempData["Success"] = "Service tariff saved.";
        return RedirectToAction(nameof(Settings));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteService(int id)
    {
        var service = await _db.EstateServices.FindAsync(id);
        if (service is null) return NotFound();

        if (await _db.Payments.AnyAsync(p => p.EstateServiceId == id))
        {
            service.IsActive = false;
            TempData["Success"] = "Service has payments recorded, so it was deactivated instead of deleted.";
        }
        else
        {
            _db.EstateServices.Remove(service);
            TempData["Success"] = "Service removed.";
        }

        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Settings));
    }

    private static UserFormViewModel ToForm(AppUser u) => new()
    {
        Id = u.Id,
        Number = u.Number,
        FirstName = u.FirstName,
        Surname = u.Surname,
        Email = u.Email,
        ContactNumber = u.ContactNumber,
        Role = u.Role,
        ResidentType = u.ResidentType,
        Status = u.Status
    };
}
