using System.Diagnostics;
using EleganceEstatePay.Models;
using Microsoft.AspNetCore.Mvc;

namespace EleganceEstatePay.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        if (!(User.Identity?.IsAuthenticated ?? false))
            return RedirectToAction("Login", "Account");

        if (User.IsInRole(nameof(UserRole.Administrator)))
            return RedirectToAction("Index", "Admin");

        if (User.IsInRole(nameof(UserRole.FinancialOfficer)))
            return RedirectToAction("Index", "Officer");

        return RedirectToAction("Index", "Resident");
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        ViewBag.RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
        return View();
    }
}
