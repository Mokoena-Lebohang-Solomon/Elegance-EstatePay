using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using EleganceEstatePay.Data;
using EleganceEstatePay.Models;
using EleganceEstatePay.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EleganceEstatePay.Controllers.Api;

// Request contracts deliberately use strings for enum-like values.  The MVC application renders
// enum names (for example, "Student" and "Active"), so these routes accept those same values.
public sealed class ApiProfileRequest
{
    public string? FirstName { get; init; }
    public string? Surname { get; init; }
    public string? Email { get; init; }
    public string? ContactNumber { get; init; }
    public string? BankName { get; init; }
    public string? BankAccountNumber { get; init; }
}

public sealed class ApiResidentCreateRequest
{
    public string? Number { get; init; }
    public string? Name { get; init; } // Supported for compact mobile forms; firstName/surname remain preferred.
    public string? FirstName { get; init; }
    public string? Surname { get; init; }
    public string? Email { get; init; }
    public string? ContactNumber { get; init; }
    public string? Type { get; init; }
    public string? ResidentType { get; init; }
    public string? Status { get; init; }
    public string? Password { get; init; }
}

public sealed class ApiResidentUpdateRequest
{
    public string? Number { get; init; }
    public string? Name { get; init; }
    public string? FirstName { get; init; }
    public string? Surname { get; init; }
    public string? Email { get; init; }
    public string? ContactNumber { get; init; }
    public string? Type { get; init; }
    public string? ResidentType { get; init; }
    public string? Status { get; init; }
    public string? Password { get; init; }
}

public sealed class ApiReviewRequest
{
    public int PaymentId { get; init; }
    public int Stars { get; init; }
    public string? Comment { get; init; }
}

public sealed class ApiFlagPaymentRequest
{
    public string? Note { get; init; }
}

public sealed class ApiServicesUpdateRequest
{
    public List<ApiServiceUpdateItem>? Items { get; init; }
}

public sealed class ApiServiceUpdateItem
{
    public int Id { get; init; }
    public string? Name { get; init; }
    public string? Description { get; init; }
    public decimal Tariff { get; init; }
    public string? BillingPeriod { get; init; }
    public bool IsActive { get; init; }
}

/// <summary>Common, non-sensitive DTO and validation helpers for the mobile API.</summary>
internal static class MobileApiSupport
{
    public static int CurrentUserId(ClaimsPrincipal principal) =>
        int.Parse(principal.FindFirstValue(ClaimTypes.NameIdentifier)!);

    public static object UserDto(AppUser user) => new
    {
        user.Id,
        user.Number,
        user.FirstName,
        user.Surname,
        user.FullName,
        user.Email,
        user.ContactNumber,
        role = user.Role.ToString(),
        residentType = user.ResidentType.ToString(),
        status = user.Status.ToString(),
        user.IsAuthorised,
        user.Permissions,
        user.BankName,
        user.BankAccountNumber
    };

    public static bool TryResidentType(string? value, out ResidentType type)
    {
        value = value?.Trim();
        if (Enum.TryParse(value, true, out type) && Enum.IsDefined(type)) return true;
        if (int.TryParse(value, out var numeric) && Enum.IsDefined((ResidentType)numeric))
        {
            type = (ResidentType)numeric;
            return true;
        }
        type = default;
        return false;
    }

    public static bool TryAccountStatus(string? value, out AccountStatus status)
    {
        value = value?.Trim();
        if (Enum.TryParse(value, true, out status) && Enum.IsDefined(status)) return true;
        if (int.TryParse(value, out var numeric) && Enum.IsDefined((AccountStatus)numeric))
        {
            status = (AccountStatus)numeric;
            return true;
        }
        status = default;
        return false;
    }

    public static void SplitName(string? suppliedName, ref string? firstName, ref string? surname)
    {
        if (!string.IsNullOrWhiteSpace(firstName) || !string.IsNullOrWhiteSpace(surname) || string.IsNullOrWhiteSpace(suppliedName))
            return;

        var parts = suppliedName.Trim().Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
        firstName = parts.ElementAtOrDefault(0);
        surname = parts.ElementAtOrDefault(1);
    }

    /// <summary>Uses the existing MVC form model and its institutional-email validation.</summary>
    public static string? ValidateUser(UserFormViewModel model, bool requireContact, string? password = null, bool passwordRequired = false)
    {
        if (string.IsNullOrWhiteSpace(model.Number) || string.IsNullOrWhiteSpace(model.FirstName) ||
            string.IsNullOrWhiteSpace(model.Surname) || string.IsNullOrWhiteSpace(model.Email))
            return "Number, first name, surname and email are required.";
        if (passwordRequired && string.IsNullOrWhiteSpace(password))
            return "A password is required for a new account.";
        if (!string.IsNullOrWhiteSpace(password) && password.Length < 6)
            return "Password must be at least 6 characters long.";
        if (requireContact && string.IsNullOrWhiteSpace(model.ContactNumber))
            return "A contact number is required.";

        var errors = new List<ValidationResult>();
        if (!Validator.TryValidateObject(model, new ValidationContext(model), errors, validateAllProperties: true))
            return errors.FirstOrDefault()?.ErrorMessage ?? "The account details are invalid.";

        if (model.FirstName.Length > 80 || model.Surname.Length > 80 || model.Email.Length > 160 ||
            model.Number.Length > 20 || model.ContactNumber?.Length > 30)
            return "One or more account fields are too long.";

        return null;
    }

    public static string? ValidateProfile(AppUser user, string firstName, string surname, string email, string? contact,
        string? bankName, string? bankAccountNumber)
    {
        if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(surname) || string.IsNullOrWhiteSpace(email))
            return "First name, surname and email are required.";
        if (!new EmailAddressAttribute().IsValid(email))
            return "Enter a valid email address.";
        if (firstName.Length > 80 || surname.Length > 80 || email.Length > 160 || contact?.Length > 30 ||
            bankName?.Length > 80 || bankAccountNumber?.Length > 64)
            return "One or more profile fields are too long.";

        // This is the same resident/financial-officer email rule used by UserFormViewModel.
        if (user.Role != UserRole.Administrator)
        {
            var type = user.Role == UserRole.FinancialOfficer ? ResidentType.Staff : user.ResidentType;
            var institutionalError = InstitutionalEmail.Error(type, user.Number, surname, email);
            if (institutionalError is not null) return institutionalError;
        }
        return null;
    }

    public static void ApplyProfile(AppUser user, string firstName, string surname, string email, string? contact,
        string? bankName, string? bankAccountNumber)
    {
        user.FirstName = firstName.Trim();
        user.Surname = surname.Trim();
        user.Email = email.Trim();
        user.ContactNumber = TrimOrNull(contact);
        user.BankName = TrimOrNull(bankName);
        user.BankAccountNumber = TrimOrNull(bankAccountNumber);
    }

    public static string? TrimOrNull(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    public static object ResidentDto(AppUser user) => new
    {
        user.Id,
        user.Number,
        user.FirstName,
        user.Surname,
        user.FullName,
        user.Email,
        user.ContactNumber,
        residentType = user.ResidentType.ToString(),
        status = user.Status.ToString(),
        user.CreatedOn
    };

    public static object OfficerDto(AppUser user) => new
    {
        user.Id,
        user.Number,
        user.FirstName,
        user.Surname,
        user.FullName,
        user.Email,
        user.ContactNumber,
        residentType = user.ResidentType.ToString(),
        status = user.Status.ToString(),
        user.IsAuthorised,
        user.AuthorisedOn,
        user.Permissions,
        user.CreatedOn
    };

    public static object ReviewDto(ServiceReview review) => new
    {
        review.Id,
        review.PaymentId,
        review.Stars,
        review.Comment,
        review.CreatedOn,
        resident = review.Resident is null ? null : new
        {
            review.Resident.Id, review.Resident.Number, review.Resident.FirstName,
            review.Resident.Surname, review.Resident.FullName
        },
        officer = review.Officer is null ? null : new
        {
            review.Officer.Id, review.Officer.Number, review.Officer.FirstName,
            review.Officer.Surname, review.Officer.FullName
        },
        payment = review.Payment is null ? null : new
        {
            review.Payment.Id, review.Payment.Reference, review.Payment.Amount,
            status = review.Payment.Status.ToString(), service = review.Payment.EstateService?.Name
        }
    };
}

// ---------------- Authenticated account identity ----------------

[ApiController]
[Route("api/auth")]
[Authorize(AuthenticationSchemes = ApiRules.Scheme)]
public class MobileAuthApiController : ControllerBase
{
    private readonly AppDbContext _db;
    public MobileAuthApiController(AppDbContext db) => _db = db;

    /// <summary>Returns the signed-in bearer-token user's safe account fields.</summary>
    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var user = await _db.Users.AsNoTracking()
            .FirstOrDefaultAsync(u => u.Id == MobileApiSupport.CurrentUserId(User));
        return user is null ? Unauthorized(new { error = "The account no longer exists." }) : Ok(MobileApiSupport.UserDto(user));
    }
}

// ---------------- Resident additions ----------------

[ApiController]
[Route("api/resident")]
[Authorize(AuthenticationSchemes = ApiRules.Scheme, Roles = "Resident")]
public class MobileResidentApiController : ControllerBase
{
    private readonly AppDbContext _db;
    public MobileResidentApiController(AppDbContext db) => _db = db;
    private int Uid => MobileApiSupport.CurrentUserId(User);

    [HttpPatch("profile")]
    public async Task<IActionResult> UpdateProfile(ApiProfileRequest request)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == Uid);
        if (user is null) return Unauthorized(new { error = "The account no longer exists." });

        var firstName = request.FirstName ?? user.FirstName;
        var surname = request.Surname ?? user.Surname;
        var email = request.Email ?? user.Email;
        var contact = request.ContactNumber ?? user.ContactNumber;
        var bankName = request.BankName ?? user.BankName;
        var bankAccountNumber = request.BankAccountNumber ?? user.BankAccountNumber;
        var error = MobileApiSupport.ValidateProfile(user, firstName, surname, email, contact,
            bankName, bankAccountNumber);
        if (error is not null) return BadRequest(new { error });

        if (await _db.Users.AnyAsync(u => u.Email == email.Trim() && u.Id != user.Id))
            return BadRequest(new { error = "That email address is already in use." });

        MobileApiSupport.ApplyProfile(user, firstName, surname, email, contact, bankName, bankAccountNumber);
        await _db.SaveChangesAsync();
        return Ok(MobileApiSupport.UserDto(user));
    }

    [HttpGet("rateable-payments")]
    public async Task<IActionResult> RateablePayments() => Ok(await _db.Payments.AsNoTracking()
        .Where(p => p.AppUserId == Uid && p.Status == PaymentStatus.Paid && p.ProcessedByUserId != null)
        .OrderByDescending(p => p.ProcessedOn)
        .Select(p => new
        {
            p.Id,
            service = p.EstateService!.Name,
            p.Amount,
            p.Reference,
            officerId = p.ProcessedByUserId,
            officerName = p.ProcessedBy!.FirstName + " " + p.ProcessedBy.Surname,
            status = p.Status.ToString()
        }).ToListAsync());

    [HttpPost("reviews")]
    public async Task<IActionResult> CreateReview(ApiReviewRequest request)
    {
        if (request.Stars is < 1 or > 5) return BadRequest(new { error = "Stars must be between 1 and 5." });
        if (request.Comment?.Length > 600) return BadRequest(new { error = "Comment cannot exceed 600 characters." });

        var payment = await _db.Payments
            .Include(p => p.EstateService)
            .Include(p => p.ProcessedBy)
            .FirstOrDefaultAsync(p => p.Id == request.PaymentId && p.AppUserId == Uid &&
                                      p.Status == PaymentStatus.Paid && p.ProcessedByUserId != null);
        if (payment is null)
            return NotFound(new { error = "A paid payment processed for your account was not found." });

        var review = new ServiceReview
        {
            ResidentUserId = Uid,
            OfficerUserId = payment.ProcessedByUserId!.Value,
            PaymentId = payment.Id,
            Stars = request.Stars,
            Comment = MobileApiSupport.TrimOrNull(request.Comment),
            CreatedOn = DateTime.UtcNow
        };
        _db.ServiceReviews.Add(review);
        await _db.SaveChangesAsync();

        return Created($"/api/resident/reviews/{review.Id}", new
        {
            review.Id,
            review.PaymentId,
            review.Stars,
            review.Comment,
            review.CreatedOn,
            officerId = payment.ProcessedByUserId,
            officerName = payment.ProcessedBy!.FullName,
            service = payment.EstateService!.Name
        });
    }
}

// ---------------- Financial officer ----------------

[ApiController]
[Route("api/officer")]
[Authorize(AuthenticationSchemes = ApiRules.Scheme, Roles = "FinancialOfficer,Administrator")]
public class MobileOfficerApiController : ControllerBase
{
    private readonly AppDbContext _db;
    public MobileOfficerApiController(AppDbContext db) => _db = db;
    private int Uid => MobileApiSupport.CurrentUserId(User);

    [HttpGet("dashboard")]
    public async Task<IActionResult> Dashboard()
    {
        var pending = await _db.Payments.AsNoTracking()
            .Where(p => p.Status == PaymentStatus.Pending)
            .OrderBy(p => p.SubmittedOn).Take(15)
            .Select(p => new
            {
                p.Id,
                resident = p.AppUser!.FirstName + " " + p.AppUser.Surname,
                unit = p.AppUser!.Number,
                service = p.EstateService!.Name,
                p.Amount,
                p.Reference,
                status = p.Status.ToString(),
                submittedOn = p.SubmittedOn
            }).ToListAsync();

        var ratings = _db.ServiceReviews.AsNoTracking().Where(r => r.OfficerUserId == Uid);
        return Ok(new
        {
            pendingCount = await _db.Payments.CountAsync(p => p.Status == PaymentStatus.Pending),
            residentCount = await _db.Users.CountAsync(u => u.Role == UserRole.Resident),
            averageRating = await ratings.AnyAsync() ? await ratings.AverageAsync(r => (double)r.Stars) : 0d,
            pendingPayments = pending
        });
    }

    [HttpGet("payments")]
    public async Task<IActionResult> Payments() => Ok(await _db.Payments.AsNoTracking()
        .Where(p => p.Status == PaymentStatus.Pending || p.Status == PaymentStatus.Flagged)
        .OrderBy(p => p.SubmittedOn)
        .Select(p => new
        {
            p.Id,
            residentId = p.AppUserId,
            resident = p.AppUser!.FirstName + " " + p.AppUser.Surname,
            unit = p.AppUser!.Number,
            service = p.EstateService!.Name,
            p.Amount,
            p.Method,
            p.Reference,
            status = p.Status.ToString(),
            p.SubmittedOn,
            p.ProcessedOn,
            p.OfficerNote,
            processedById = p.ProcessedByUserId,
            processedBy = p.ProcessedBy == null ? null : p.ProcessedBy.FirstName + " " + p.ProcessedBy.Surname
        }).ToListAsync());

    [HttpGet("payments/{id:int}")]
    public async Task<IActionResult> Payment(int id)
    {
        var payment = await _db.Payments.AsNoTracking()
            .Include(p => p.AppUser).Include(p => p.EstateService).Include(p => p.ProcessedBy)
            .FirstOrDefaultAsync(p => p.Id == id);
        if (payment is null) return NotFound(new { error = "Payment not found." });

        var outstanding = await _db.Payments.AsNoTracking()
            .Where(p => p.AppUserId == payment.AppUserId && p.Status == PaymentStatus.Pending)
            .SumAsync(p => (decimal?)p.Amount) ?? 0m;
        var last = await _db.Payments.AsNoTracking().Include(p => p.EstateService)
            .Where(p => p.AppUserId == payment.AppUserId && p.Status == PaymentStatus.Paid)
            .OrderByDescending(p => p.ProcessedOn).FirstOrDefaultAsync();

        return Ok(new
        {
            payment = new
            {
                payment.Id,
                service = payment.EstateService!.Name,
                tariff = payment.EstateService.Tariff,
                billingPeriod = payment.EstateService.BillingPeriod,
                payment.Amount,
                payment.Method,
                payment.Reference,
                status = payment.Status.ToString(),
                payment.SubmittedOn,
                payment.ProcessedOn,
                payment.OfficerNote,
                processedById = payment.ProcessedByUserId,
                processedBy = payment.ProcessedBy?.FullName
            },
            resident = new
            {
                payment.AppUser!.Id,
                payment.AppUser.Number,
                payment.AppUser.FirstName,
                payment.AppUser.Surname,
                payment.AppUser.FullName,
                payment.AppUser.Email,
                payment.AppUser.ContactNumber,
                residentType = payment.AppUser.ResidentType.ToString(),
                status = payment.AppUser.Status.ToString(),
                outstandingBalance = outstanding
            },
            lastPayment = last is null ? null : new
            {
                last.Id,
                service = last.EstateService!.Name,
                last.Amount,
                last.Reference,
                status = last.Status.ToString(),
                last.ProcessedOn
            }
        });
    }

    [HttpPatch("payments/{id:int}/confirm")]
    public async Task<IActionResult> ConfirmPayment(int id)
    {
        var payment = await _db.Payments.Include(p => p.EstateService).FirstOrDefaultAsync(p => p.Id == id);
        if (payment is null) return NotFound(new { error = "Payment not found." });

        // Match OfficerController.Confirm: the current officer records the decision and the resident is notified.
        payment.Status = PaymentStatus.Paid;
        payment.ProcessedOn = DateTime.UtcNow;
        payment.ProcessedByUserId = Uid;
        _db.Notifications.Add(new Notification
        {
            AppUserId = payment.AppUserId,
            Title = "Payment Confirmed",
            Message = $"Your {payment.EstateService?.Name} payment of R {payment.Amount:N2} was received.",
            IconClass = "fa-solid fa-circle-check"
        });
        await _db.SaveChangesAsync();
        return Ok(new { message = "Payment confirmed.", id = payment.Id, status = payment.Status.ToString(), payment.ProcessedOn });
    }

    [HttpPatch("payments/{id:int}/flag")]
    public async Task<IActionResult> FlagPayment(int id, ApiFlagPaymentRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Note)) return BadRequest(new { error = "A reason or note is required." });
        if (request.Note.Length > 400) return BadRequest(new { error = "The officer note cannot exceed 400 characters." });

        var payment = await _db.Payments.Include(p => p.EstateService).FirstOrDefaultAsync(p => p.Id == id);
        if (payment is null) return NotFound(new { error = "Payment not found." });

        payment.Status = PaymentStatus.Flagged;
        payment.ProcessedOn = DateTime.UtcNow;
        payment.ProcessedByUserId = Uid;
        payment.OfficerNote = request.Note.Trim();
        _db.Notifications.Add(new Notification
        {
            AppUserId = payment.AppUserId,
            Title = "Payment Flagged for Review",
            Message = $"Your {payment.EstateService?.Name} payment of R {payment.Amount:N2} needs attention. {payment.OfficerNote}",
            IconClass = "fa-solid fa-triangle-exclamation"
        });
        await _db.SaveChangesAsync();
        return Ok(new { message = "Payment flagged for review.", id = payment.Id, status = payment.Status.ToString(), payment.ProcessedOn, payment.OfficerNote });
    }

    [HttpGet("residents")]
    public async Task<IActionResult> Residents(string? q)
    {
        var query = _db.Users.AsNoTracking().Where(u => u.Role == UserRole.Resident);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(u => u.Number.Contains(term) || u.FirstName.Contains(term) || u.Surname.Contains(term));
        }
        var users = await query.OrderBy(u => u.Surname).ThenBy(u => u.FirstName).ToListAsync();
        return Ok(users.Select(MobileApiSupport.ResidentDto));
    }

    [HttpPost("residents")]
    public async Task<IActionResult> CreateResident(ApiResidentCreateRequest request) =>
        await CreateResidentCore(request);

    [HttpPatch("residents/{id:int}")]
    public async Task<IActionResult> UpdateResident(int id, ApiResidentUpdateRequest request)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == id && u.Role == UserRole.Resident);
        if (user is null) return NotFound(new { error = "Resident not found." });

        var firstName = request.FirstName ?? user.FirstName;
        var surname = request.Surname ?? user.Surname;
        MobileApiSupport.SplitName(request.Name, ref firstName, ref surname);
        var number = request.Number ?? user.Number;
        var email = request.Email ?? user.Email;
        var typeText = request.Type ?? request.ResidentType;
        var residentType = user.ResidentType;
        if (typeText is not null && !MobileApiSupport.TryResidentType(typeText, out residentType))
            return BadRequest(new { error = "Type must be Student, Staff or NotApplicable." });
        var status = user.Status;
        if (request.Status is not null && !MobileApiSupport.TryAccountStatus(request.Status, out status))
            return BadRequest(new { error = "Status must be Active, Suspended or Deactivated." });

        var form = new UserFormViewModel
        {
            Id = user.Id, Number = number, FirstName = firstName, Surname = surname, Email = email,
            ContactNumber = request.ContactNumber ?? user.ContactNumber, Role = UserRole.Resident,
            ResidentType = residentType, Status = status
        };
        var error = MobileApiSupport.ValidateUser(form, requireContact: false, request.Password);
        if (error is not null) return BadRequest(new { error });
        if (await _db.Users.AnyAsync(u => (u.Number == number.Trim() || u.Email == email.Trim()) && u.Id != user.Id))
            return BadRequest(new { error = "That number or email address is already in use." });

        user.Number = number.Trim();
        user.FirstName = firstName.Trim();
        user.Surname = surname.Trim();
        user.Email = email.Trim();
        user.ContactNumber = MobileApiSupport.TrimOrNull(request.ContactNumber ?? user.ContactNumber);
        user.ResidentType = residentType;
        user.Status = status;
        if (!string.IsNullOrWhiteSpace(request.Password))
        {
            user.PasswordHash = PasswordHasher.Hash(request.Password);
            _db.Notifications.Add(new Notification
            {
                AppUserId = user.Id,
                Title = "Password Reset",
                Message = "A financial officer reset your password. Please sign in and change it.",
                IconClass = "fa-solid fa-key"
            });
        }
        await _db.SaveChangesAsync();
        return Ok(MobileApiSupport.ResidentDto(user));
    }

    [HttpDelete("residents/{id:int}")]
    public async Task<IActionResult> DeleteResident(int id)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == id && u.Role == UserRole.Resident);
        if (user is null) return NotFound(new { error = "Resident not found." });
        if (await _db.ServiceReviews.AnyAsync(r => r.ResidentUserId == id))
            return BadRequest(new { error = "This resident has submitted reviews and cannot be deleted." });
        _db.Users.Remove(user);
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpGet("reviews")]
    public async Task<IActionResult> Reviews()
    {
        var reviews = await _db.ServiceReviews.AsNoTracking()
            .Include(r => r.Resident).Include(r => r.Officer).Include(r => r.Payment).ThenInclude(p => p!.EstateService)
            .Where(r => r.OfficerUserId == Uid)
            .OrderByDescending(r => r.CreatedOn).ToListAsync();
        return Ok(reviews.Select(MobileApiSupport.ReviewDto));
    }

    [HttpGet("profile")]
    public async Task<IActionResult> Profile()
    {
        var user = await _db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == Uid);
        return user is null ? Unauthorized(new { error = "The account no longer exists." }) : Ok(MobileApiSupport.UserDto(user));
    }

    [HttpPatch("profile")]
    public async Task<IActionResult> UpdateProfile(ApiProfileRequest request) => await UpdateOwnProfile(request);

    private async Task<IActionResult> CreateResidentCore(ApiResidentCreateRequest request)
    {
        var firstName = request.FirstName;
        var surname = request.Surname;
        MobileApiSupport.SplitName(request.Name, ref firstName, ref surname);
        if (!MobileApiSupport.TryResidentType(request.Type ?? request.ResidentType, out var residentType))
            return BadRequest(new { error = "Type is required and must be Student, Staff or NotApplicable." });
        var status = AccountStatus.Active;
        if (request.Status is not null && !MobileApiSupport.TryAccountStatus(request.Status, out status))
            return BadRequest(new { error = "Status must be Active, Suspended or Deactivated." });

        var form = new UserFormViewModel
        {
            Number = request.Number ?? string.Empty, FirstName = firstName ?? string.Empty, Surname = surname ?? string.Empty,
            Email = request.Email ?? string.Empty, ContactNumber = request.ContactNumber, Role = UserRole.Resident,
            ResidentType = residentType, Status = status
        };
        var error = MobileApiSupport.ValidateUser(form, requireContact: true, request.Password, passwordRequired: true);
        if (error is not null) return BadRequest(new { error });
        if (await _db.Users.AnyAsync(u => u.Number == form.Number.Trim() || u.Email == form.Email.Trim()))
            return BadRequest(new { error = "That number or email address is already in use." });

        var user = new AppUser
        {
            Number = form.Number.Trim(), FirstName = form.FirstName.Trim(), Surname = form.Surname.Trim(), Email = form.Email.Trim(),
            ContactNumber = MobileApiSupport.TrimOrNull(form.ContactNumber), Role = UserRole.Resident, ResidentType = residentType,
            Status = status, PasswordHash = PasswordHasher.Hash(request.Password!)
        };
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        _db.Notifications.Add(new Notification
        {
            AppUserId = user.Id,
            Title = "Welcome to Elegance Estate Pay",
            Message = "A financial officer created your estate account. Sign in with your student / staff number.",
            IconClass = "fa-solid fa-user-plus"
        });
        await _db.SaveChangesAsync();
        return Created($"/api/officer/residents/{user.Id}", MobileApiSupport.ResidentDto(user));
    }

    private async Task<IActionResult> UpdateOwnProfile(ApiProfileRequest request)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == Uid);
        if (user is null) return Unauthorized(new { error = "The account no longer exists." });
        var firstName = request.FirstName ?? user.FirstName;
        var surname = request.Surname ?? user.Surname;
        var email = request.Email ?? user.Email;
        var contact = request.ContactNumber ?? user.ContactNumber;
        var bankName = request.BankName ?? user.BankName;
        var bankAccountNumber = request.BankAccountNumber ?? user.BankAccountNumber;
        var error = MobileApiSupport.ValidateProfile(user, firstName, surname, email, contact,
            bankName, bankAccountNumber);
        if (error is not null) return BadRequest(new { error });
        if (await _db.Users.AnyAsync(u => u.Email == email.Trim() && u.Id != user.Id))
            return BadRequest(new { error = "That email address is already in use." });
        MobileApiSupport.ApplyProfile(user, firstName, surname, email, contact, bankName, bankAccountNumber);
        await _db.SaveChangesAsync();
        return Ok(MobileApiSupport.UserDto(user));
    }
}

// ---------------- Administrator ----------------

[ApiController]
[Route("api/admin")]
[Authorize(AuthenticationSchemes = ApiRules.Scheme, Roles = "Administrator")]
public class MobileAdminApiController : ControllerBase
{
    private readonly AppDbContext _db;
    public MobileAdminApiController(AppDbContext db) => _db = db;
    private int Uid => MobileApiSupport.CurrentUserId(User);

    [HttpGet("dashboard")]
    public async Task<IActionResult> Dashboard()
    {
        var today = DateTime.UtcNow.Date;
        var activity = await _db.Payments.AsNoTracking().OrderByDescending(p => p.SubmittedOn).Take(10)
            .Select(p => new
            {
                p.Id,
                resident = p.AppUser!.FirstName + " " + p.AppUser.Surname,
                residentNumber = p.AppUser!.Number,
                service = p.EstateService!.Name,
                p.Amount,
                p.Reference,
                status = p.Status.ToString(),
                p.SubmittedOn,
                p.ProcessedOn,
                processedBy = p.ProcessedBy == null ? null : p.ProcessedBy.FirstName + " " + p.ProcessedBy.Surname,
                p.OfficerNote
            }).ToListAsync();
        return Ok(new
        {
            totalResidents = await _db.Users.CountAsync(u => u.Role == UserRole.Resident),
            activeOfficers = await _db.Users.CountAsync(u => u.Role == UserRole.FinancialOfficer && u.IsAuthorised && u.Status == AccountStatus.Active),
            paymentsToday = await _db.Payments.Where(p => p.Status == PaymentStatus.Paid && p.ProcessedOn != null && p.ProcessedOn!.Value.Date == today)
                .SumAsync(p => (decimal?)p.Amount) ?? 0m,
            pendingReviews = await _db.Payments.CountAsync(p => p.Status == PaymentStatus.Pending || p.Status == PaymentStatus.Flagged),
            recentActivity = activity
        });
    }

    [HttpGet("residents")]
    public async Task<IActionResult> Residents(string? q)
    {
        var query = _db.Users.AsNoTracking().Where(u => u.Role == UserRole.Resident);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(u => u.Number.Contains(term) || u.FirstName.Contains(term) || u.Surname.Contains(term));
        }
        var users = await query.OrderBy(u => u.Surname).ThenBy(u => u.FirstName).ToListAsync();
        return Ok(users.Select(MobileApiSupport.ResidentDto));
    }

    [HttpPost("residents")]
    public async Task<IActionResult> CreateResident(ApiResidentCreateRequest request)
    {
        var firstName = request.FirstName;
        var surname = request.Surname;
        MobileApiSupport.SplitName(request.Name, ref firstName, ref surname);
        if (!MobileApiSupport.TryResidentType(request.Type ?? request.ResidentType, out var residentType))
            return BadRequest(new { error = "Type is required and must be Student, Staff or NotApplicable." });
        var status = AccountStatus.Active;
        if (request.Status is not null && !MobileApiSupport.TryAccountStatus(request.Status, out status))
            return BadRequest(new { error = "Status must be Active, Suspended or Deactivated." });
        var form = new UserFormViewModel
        {
            Number = request.Number ?? string.Empty, FirstName = firstName ?? string.Empty, Surname = surname ?? string.Empty,
            Email = request.Email ?? string.Empty, ContactNumber = request.ContactNumber, Role = UserRole.Resident,
            ResidentType = residentType, Status = status
        };
        var error = MobileApiSupport.ValidateUser(form, requireContact: true, request.Password, passwordRequired: true);
        if (error is not null) return BadRequest(new { error });
        if (await _db.Users.AnyAsync(u => u.Number == form.Number.Trim() || u.Email == form.Email.Trim()))
            return BadRequest(new { error = "That number or email address is already in use." });
        var user = new AppUser
        {
            Number = form.Number.Trim(), FirstName = form.FirstName.Trim(), Surname = form.Surname.Trim(), Email = form.Email.Trim(),
            ContactNumber = MobileApiSupport.TrimOrNull(form.ContactNumber), Role = UserRole.Resident, ResidentType = residentType,
            Status = status, PasswordHash = PasswordHasher.Hash(request.Password!)
        };
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        return Created($"/api/admin/residents/{user.Id}", MobileApiSupport.ResidentDto(user));
    }

    [HttpPatch("residents/{id:int}")]
    public async Task<IActionResult> UpdateResident(int id, ApiResidentUpdateRequest request) =>
        await UpdateResidentCore(id, request);

    [HttpPatch("residents/{id:int}/status")]
    public async Task<IActionResult> ToggleResidentStatus(int id)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == id && u.Role == UserRole.Resident);
        if (user is null) return NotFound(new { error = "Resident not found." });
        user.Status = user.Status == AccountStatus.Active ? AccountStatus.Suspended : AccountStatus.Active;
        await _db.SaveChangesAsync();
        return Ok(new { message = $"{user.FullName} is now {user.Status}.", status = user.Status.ToString() });
    }

    [HttpDelete("residents/{id:int}")]
    public async Task<IActionResult> DeleteResident(int id) => await DeleteUser(id, UserRole.Resident, "Resident");

    [HttpGet("officers")]
    public async Task<IActionResult> Officers()
    {
        var officers = await _db.Users.AsNoTracking().Where(u => u.Role == UserRole.FinancialOfficer)
            .OrderBy(u => u.Surname).ThenBy(u => u.FirstName).ToListAsync();
        return Ok(officers.Select(MobileApiSupport.OfficerDto));
    }

    [HttpPost("officers")]
    public async Task<IActionResult> CreateOfficer(ApiResidentCreateRequest request)
    {
        var firstName = request.FirstName;
        var surname = request.Surname;
        MobileApiSupport.SplitName(request.Name, ref firstName, ref surname);
        var status = AccountStatus.Active;
        if (request.Status is not null && !MobileApiSupport.TryAccountStatus(request.Status, out status))
            return BadRequest(new { error = "Status must be Active, Suspended or Deactivated." });
        var form = new UserFormViewModel
        {
            Number = request.Number ?? string.Empty, FirstName = firstName ?? string.Empty, Surname = surname ?? string.Empty,
            Email = request.Email ?? string.Empty, ContactNumber = request.ContactNumber, Role = UserRole.FinancialOfficer,
            ResidentType = ResidentType.Staff, Status = status
        };
        var error = MobileApiSupport.ValidateUser(form, requireContact: true, request.Password, passwordRequired: true);
        if (error is not null) return BadRequest(new { error });
        if (await _db.Users.AnyAsync(u => u.Number == form.Number.Trim() || u.Email == form.Email.Trim()))
            return BadRequest(new { error = "That number or email address is already in use." });

        var user = new AppUser
        {
            Number = form.Number.Trim(), FirstName = form.FirstName.Trim(), Surname = form.Surname.Trim(), Email = form.Email.Trim(),
            ContactNumber = MobileApiSupport.TrimOrNull(form.ContactNumber), Role = UserRole.FinancialOfficer,
            ResidentType = ResidentType.Staff, Status = status, IsAuthorised = false,
            PasswordHash = PasswordHasher.Hash(request.Password!)
        };
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        return Created($"/api/admin/officers/{user.Id}", MobileApiSupport.OfficerDto(user));
    }

    [HttpPatch("officers/{id:int}/authorise")]
    public async Task<IActionResult> ToggleOfficerAuthorisation(int id)
    {
        var officer = await _db.Users.FirstOrDefaultAsync(u => u.Id == id && u.Role == UserRole.FinancialOfficer);
        if (officer is null) return NotFound(new { error = "Financial officer not found." });
        officer.IsAuthorised = !officer.IsAuthorised;
        officer.AuthorisedOn = officer.IsAuthorised ? DateTime.UtcNow : null;
        await _db.SaveChangesAsync();
        return Ok(new
        {
            message = officer.IsAuthorised ? $"{officer.FullName} is authorised to process payments." : $"{officer.FullName}'s authorisation has been withdrawn.",
            officer.IsAuthorised,
            officer.AuthorisedOn
        });
    }

    [HttpPatch("officers/{id:int}/status")]
    public async Task<IActionResult> ToggleOfficerStatus(int id)
    {
        var officer = await _db.Users.FirstOrDefaultAsync(u => u.Id == id && u.Role == UserRole.FinancialOfficer);
        if (officer is null) return NotFound(new { error = "Financial officer not found." });
        officer.Status = officer.Status == AccountStatus.Active ? AccountStatus.Suspended : AccountStatus.Active;
        await _db.SaveChangesAsync();
        return Ok(new { message = $"{officer.FullName} is now {officer.Status}.", status = officer.Status.ToString() });
    }

    [HttpDelete("officers/{id:int}")]
    public async Task<IActionResult> DeleteOfficer(int id) => await DeleteUser(id, UserRole.FinancialOfficer, "Financial officer");

    [HttpGet("activity")]
    public async Task<IActionResult> Activity() => Ok(await _db.Payments.AsNoTracking()
        .Where(p => p.ProcessedByUserId != null).OrderByDescending(p => p.ProcessedOn).Take(200)
        .Select(p => new
        {
            p.Id,
            p.ProcessedOn,
            officerId = p.ProcessedByUserId,
            officer = p.ProcessedBy!.FirstName + " " + p.ProcessedBy.Surname,
            residentId = p.AppUserId,
            resident = p.AppUser!.FirstName + " " + p.AppUser.Surname,
            residentNumber = p.AppUser!.Number,
            service = p.EstateService!.Name,
            p.Amount,
            p.Method,
            p.Reference,
            status = p.Status.ToString(),
            p.OfficerNote
        }).ToListAsync());

    [HttpGet("reviews")]
    public async Task<IActionResult> Reviews()
    {
        var reviews = await _db.ServiceReviews.AsNoTracking()
            .Include(r => r.Resident).Include(r => r.Officer).Include(r => r.Payment).ThenInclude(p => p!.EstateService)
            .OrderByDescending(r => r.CreatedOn).ToListAsync();
        return Ok(reviews.Select(MobileApiSupport.ReviewDto));
    }

    [HttpGet("profile")]
    public async Task<IActionResult> Profile()
    {
        var user = await _db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == Uid);
        return user is null ? Unauthorized(new { error = "The account no longer exists." }) : Ok(MobileApiSupport.UserDto(user));
    }

    [HttpPatch("profile")]
    public async Task<IActionResult> UpdateProfile(ApiProfileRequest request)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == Uid);
        if (user is null) return Unauthorized(new { error = "The account no longer exists." });
        var firstName = request.FirstName ?? user.FirstName;
        var surname = request.Surname ?? user.Surname;
        var email = request.Email ?? user.Email;
        var contact = request.ContactNumber ?? user.ContactNumber;
        var bankName = request.BankName ?? user.BankName;
        var bankAccountNumber = request.BankAccountNumber ?? user.BankAccountNumber;
        var error = MobileApiSupport.ValidateProfile(user, firstName, surname, email, contact,
            bankName, bankAccountNumber);
        if (error is not null) return BadRequest(new { error });
        if (await _db.Users.AnyAsync(u => u.Email == email.Trim() && u.Id != user.Id))
            return BadRequest(new { error = "That email address is already in use." });
        MobileApiSupport.ApplyProfile(user, firstName, surname, email, contact, bankName, bankAccountNumber);
        await _db.SaveChangesAsync();
        return Ok(MobileApiSupport.UserDto(user));
    }

    [HttpGet("services")]
    public async Task<IActionResult> Services() => Ok(await _db.EstateServices.AsNoTracking().OrderBy(s => s.Name)
        .Select(s => new { s.Id, s.Name, s.Description, s.Tariff, s.BillingPeriod, s.IsActive }).ToListAsync());

    [HttpPatch("services")]
    public async Task<IActionResult> UpdateServices(ApiServicesUpdateRequest request)
    {
        if (request.Items is null || request.Items.Count == 0)
            return BadRequest(new { error = "Provide at least one service item." });
        if (request.Items.Select(i => i.Id).Distinct().Count() != request.Items.Count || request.Items.Any(i => i.Id <= 0 ||
            string.IsNullOrWhiteSpace(i.Name) || i.Name.Length > 60 || i.Description?.Length > 200 || i.Tariff < 0 ||
            string.IsNullOrWhiteSpace(i.BillingPeriod) || i.BillingPeriod.Length > 40))
            return BadRequest(new { error = "Each service needs an id, name, non-negative tariff and billing period." });

        var ids = request.Items.Select(i => i.Id).ToArray();
        var services = await _db.EstateServices.Where(s => ids.Contains(s.Id)).ToDictionaryAsync(s => s.Id);
        if (services.Count != ids.Length) return NotFound(new { error = "One or more services were not found." });

        foreach (var item in request.Items)
        {
            var service = services[item.Id];
            service.Name = item.Name!.Trim();
            service.Description = MobileApiSupport.TrimOrNull(item.Description);
            service.Tariff = decimal.Round(item.Tariff, 2);
            service.BillingPeriod = item.BillingPeriod!.Trim();
            service.IsActive = item.IsActive;
        }
        await _db.SaveChangesAsync();
        return Ok(request.Items.Select(i =>
        {
            var service = services[i.Id];
            return new { service.Id, service.Name, service.Description, service.Tariff, service.BillingPeriod, service.IsActive };
        }));
    }

    private async Task<IActionResult> UpdateResidentCore(int id, ApiResidentUpdateRequest request)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == id && u.Role == UserRole.Resident);
        if (user is null) return NotFound(new { error = "Resident not found." });
        var firstName = request.FirstName ?? user.FirstName;
        var surname = request.Surname ?? user.Surname;
        MobileApiSupport.SplitName(request.Name, ref firstName, ref surname);
        var number = request.Number ?? user.Number;
        var email = request.Email ?? user.Email;
        var typeText = request.Type ?? request.ResidentType;
        var residentType = user.ResidentType;
        if (typeText is not null && !MobileApiSupport.TryResidentType(typeText, out residentType))
            return BadRequest(new { error = "Type must be Student, Staff or NotApplicable." });
        var status = user.Status;
        if (request.Status is not null && !MobileApiSupport.TryAccountStatus(request.Status, out status))
            return BadRequest(new { error = "Status must be Active, Suspended or Deactivated." });
        var form = new UserFormViewModel
        {
            Id = user.Id, Number = number, FirstName = firstName, Surname = surname, Email = email,
            ContactNumber = request.ContactNumber ?? user.ContactNumber, Role = UserRole.Resident,
            ResidentType = residentType, Status = status
        };
        var error = MobileApiSupport.ValidateUser(form, requireContact: false, request.Password);
        if (error is not null) return BadRequest(new { error });
        if (await _db.Users.AnyAsync(u => (u.Number == number.Trim() || u.Email == email.Trim()) && u.Id != user.Id))
            return BadRequest(new { error = "That number or email address is already in use." });
        user.Number = number.Trim();
        user.FirstName = firstName.Trim();
        user.Surname = surname.Trim();
        user.Email = email.Trim();
        user.ContactNumber = MobileApiSupport.TrimOrNull(request.ContactNumber ?? user.ContactNumber);
        user.ResidentType = residentType;
        user.Status = status;
        if (!string.IsNullOrWhiteSpace(request.Password))
        {
            user.PasswordHash = PasswordHasher.Hash(request.Password);
            _db.Notifications.Add(new Notification
            {
                AppUserId = user.Id,
                Title = "Password Reset",
                Message = "An administrator reset your password. Please sign in and change it.",
                IconClass = "fa-solid fa-key"
            });
        }
        await _db.SaveChangesAsync();
        return Ok(MobileApiSupport.ResidentDto(user));
    }

    private async Task<IActionResult> DeleteUser(int id, UserRole role, string label)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == id && u.Role == role);
        if (user is null) return NotFound(new { error = $"{label} not found." });
        if (role == UserRole.Resident && await _db.ServiceReviews.AnyAsync(r => r.ResidentUserId == id))
            return BadRequest(new { error = "This resident has submitted reviews and cannot be deleted." });
        if (role == UserRole.FinancialOfficer && (await _db.Payments.AnyAsync(p => p.ProcessedByUserId == id) ||
                                                  await _db.ServiceReviews.AnyAsync(r => r.OfficerUserId == id)))
            return BadRequest(new { error = "This financial officer has payment activity or reviews and cannot be deleted." });
        _db.Users.Remove(user);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
