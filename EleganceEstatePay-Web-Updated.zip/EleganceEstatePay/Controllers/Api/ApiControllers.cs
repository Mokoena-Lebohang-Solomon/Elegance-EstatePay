using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using EleganceEstatePay.Data;
using EleganceEstatePay.Models;
using EleganceEstatePay.Services;
using Microsoft.AspNetCore.Authentication.BearerToken;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace EleganceEstatePay.Controllers.Api;

// ---------------- Request / response contracts ----------------

public record ApiLoginRequest([Required] string Number, [Required] string Password);
public record ApiRefreshRequest([Required] string RefreshToken);
public record ApiChangePasswordRequest([Required] string CurrentPassword, [Required, MinLength(6)] string NewPassword);
public record ApiPaymentItem(int ServiceId, decimal Amount);
public record ApiPaymentRequest([Required] List<ApiPaymentItem> Items, [Required] string Method,
    string? CardHolder = null, string? CardNumber = null, string? ExpiryDate = null, string? Cvc = null);
public record ApiCalculateRequest([Required] List<ApiCalcLine> Lines, decimal VatPercentage = 15m);
public record ApiCalcLine(int ServiceId, decimal Units);

internal static class ApiRules
{
    public static readonly string[] Methods = { "EFT / Bank Transfer", "Debit Order", "Card" };
    public const string Scheme = "Bearer";
}

// ---------------- Auth ----------------

[ApiController]
[Route("api/auth")]
public class AuthApiController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IOptionsMonitor<BearerTokenOptions> _bearer;
    public AuthApiController(AppDbContext db, IOptionsMonitor<BearerTokenOptions> bearer) { _db = db; _bearer = bearer; }

    /// <summary>Login with student/staff number. Returns accessToken + refreshToken.</summary>
    [HttpPost("login")]
    public async Task<IActionResult> Login(ApiLoginRequest req)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Number == req.Number.Trim());
        if (user is null || !PasswordHasher.Verify(req.Password, user.PasswordHash))
            return Unauthorized(new { error = "Invalid student/staff number or password." });
        if (user.Status != AccountStatus.Active)
            return StatusCode(403, new { error = "This account is not active." });
        if (user.Role == UserRole.FinancialOfficer && !user.IsAuthorised)
            return StatusCode(403, new { error = "Officer account not yet authorised by the administrator." });
        return SignIn(Principal(user), ApiRules.Scheme);
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        var number = model.Number.Trim();
        if (await _db.Users.AnyAsync(u => u.Number == number))
            ModelState.AddModelError(nameof(model.Number), "That student/staff number is already registered.");
        if (await _db.Users.AnyAsync(u => u.Email == model.Email.Trim()))
            ModelState.AddModelError(nameof(model.Email), "That email address is already registered.");
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var user = new AppUser
        {
            Number = number, FirstName = model.FirstName.Trim(), Surname = model.Surname.Trim(),
            Email = model.Email.Trim(), ContactNumber = model.ContactNumber, ResidentType = model.ResidentType,
            Role = UserRole.Resident, Status = AccountStatus.Active, PasswordHash = PasswordHasher.Hash(model.Password)
        };
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        return Created($"/api/me", new { user.Id, user.Number, user.Email });
    }

    [HttpPost("refresh")]
    public async Task<IActionResult> Refresh(ApiRefreshRequest req)
    {
        var ticket = _bearer.Get(ApiRules.Scheme).RefreshTokenProtector.Unprotect(req.RefreshToken);
        if (ticket?.Properties.ExpiresUtc is not { } exp || DateTimeOffset.UtcNow >= exp) return Unauthorized();
        var id = ticket.Principal.FindFirstValue(ClaimTypes.NameIdentifier);
        var user = int.TryParse(id, out var uid) ? await _db.Users.FindAsync(uid) : null;
        if (user is null || user.Status != AccountStatus.Active) return Unauthorized();
        return SignIn(Principal(user), ApiRules.Scheme);
    }

    [Authorize(AuthenticationSchemes = ApiRules.Scheme)]
    [HttpPost("change-password")]
    public async Task<IActionResult> ChangePassword(ApiChangePasswordRequest req)
    {
        var user = await _db.Users.FindAsync(int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!));
        if (user is null) return Unauthorized();
        if (!PasswordHasher.Verify(req.CurrentPassword, user.PasswordHash))
            return BadRequest(new { error = "Your current password is incorrect." });
        user.PasswordHash = PasswordHasher.Hash(req.NewPassword);
        await _db.SaveChangesAsync();
        return Ok(new { message = "Password updated." });
    }

    private static ClaimsPrincipal Principal(AppUser user) => new(new ClaimsIdentity(new[]
    {
        new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
        new Claim(ClaimTypes.Name, user.FullName),
        new Claim("Number", user.Number),
        new Claim(ClaimTypes.Role, user.Role.ToString())
    }, ApiRules.Scheme));
}

// ---------------- Services (public tariffs) ----------------

[ApiController]
[Route("api/services")]
public class ServicesApiController : ControllerBase
{
    private readonly AppDbContext _db;
    public ServicesApiController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> Get() => Ok(await _db.EstateServices.Where(s => s.IsActive).OrderBy(s => s.Name)
        .Select(s => new { s.Id, s.Name, s.Description, s.Tariff, s.BillingPeriod }).ToListAsync());

    /// <summary>Tariff calculator: units × tariff per line, plus VAT. Amounts are what you send to /api/resident/payments.</summary>
    [HttpPost("calculate")]
    public async Task<IActionResult> Calculate(ApiCalculateRequest req)
    {
        var ids = req.Lines.Select(l => l.ServiceId).ToArray();
        var services = await _db.EstateServices.Where(s => s.IsActive && ids.Contains(s.Id)).ToDictionaryAsync(s => s.Id);
        if (req.Lines.Any(l => l.Units < 0 || !services.ContainsKey(l.ServiceId)))
            return BadRequest(new { error = "Unknown service or negative units." });
        var lines = req.Lines.Select(l => new
        {
            l.ServiceId, Service = services[l.ServiceId].Name, Tariff = services[l.ServiceId].Tariff, l.Units,
            Amount = decimal.Round(l.Units * services[l.ServiceId].Tariff, 2)
        }).ToList();
        var subtotal = lines.Sum(l => l.Amount);
        var vat = decimal.Round(subtotal * req.VatPercentage / 100m, 2);
        return Ok(new { lines, subtotal, vat, total = subtotal + vat });
    }
}

// ---------------- Resident ----------------

[ApiController]
[Route("api/resident")]
[Authorize(AuthenticationSchemes = ApiRules.Scheme, Roles = "Resident")]
public class ResidentApiController : ControllerBase
{
    private readonly AppDbContext _db;
    public ResidentApiController(AppDbContext db) => _db = db;
    private int Uid => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var u = await _db.Users.FirstAsync(x => x.Id == Uid);
        var outstanding = await _db.Payments.Where(p => p.AppUserId == Uid && (p.Status == PaymentStatus.Pending || p.Status == PaymentStatus.Flagged))
            .SumAsync(p => (decimal?)p.Amount) ?? 0m;
        return Ok(new { u.Id, u.Number, u.FirstName, u.Surname, u.Email, u.ContactNumber, ResidentType = u.ResidentType.ToString(),
            u.BankName, u.BankAccountNumber, outstandingBalance = outstanding,
            unreadNotifications = await _db.Notifications.CountAsync(n => n.AppUserId == Uid && !n.IsRead) });
    }

    [HttpGet("payments")]
    public async Task<IActionResult> Payments() => Ok(await _db.Payments.Where(p => p.AppUserId == Uid)
        .OrderByDescending(p => p.SubmittedOn)
        .Select(p => new { p.Id, Service = p.EstateService!.Name, p.Amount, p.Method, p.Reference, Status = p.Status.ToString(), p.SubmittedOn, ProcessedBy = p.ProcessedBy!.FirstName + " " + p.ProcessedBy.Surname })
        .ToListAsync());

    /// <summary>One item = individual pay; several = bulk; every service = pay all. Amounts are stored exactly as sent.</summary>
    [HttpPost("payments")]
    public async Task<IActionResult> Pay(ApiPaymentRequest req)
    {
        if (req.Items.Count == 0 || req.Items.Any(i => i.Amount <= 0 || i.Amount > 1_000_000))
            return BadRequest(new { error = "Each item needs an amount between R0.01 and R1,000,000." });
        if (!ApiRules.Methods.Contains(req.Method))
            return BadRequest(new { error = "Method must be EFT / Bank Transfer, Debit Order or Card." });

        if (req.Method == "Card")
        {
            var card = new CardPaymentViewModel
            {
                Amount = req.Items.Sum(i => i.Amount), CardHolder = req.CardHolder ?? "",
                CardNumber = req.CardNumber ?? "", ExpiryDate = req.ExpiryDate ?? "", Cvc = req.Cvc ?? ""
            };
            var results = new List<ValidationResult>();
            if (!Validator.TryValidateObject(card, new ValidationContext(card), results, true))
                return BadRequest(new { error = "Invalid card details.", details = results.Select(r => r.ErrorMessage) });
            // Card number and CVC are validated only — never stored.
        }

        var ids = req.Items.Select(i => i.ServiceId).Distinct().ToArray();
        var services = await _db.EstateServices.Where(s => s.IsActive && ids.Contains(s.Id)).ToDictionaryAsync(s => s.Id);
        if (services.Count != ids.Length) return BadRequest(new { error = "One of the services is not available." });

        var created = req.Items.Select(i => new Payment
        {
            AppUserId = Uid, EstateServiceId = i.ServiceId, Amount = decimal.Round(i.Amount, 2), Method = req.Method,
            Reference = ReferenceGenerator.Next(), Status = PaymentStatus.Pending, SubmittedOn = DateTime.UtcNow
        }).ToList();
        _db.Payments.AddRange(created);
        _db.Notifications.Add(new Notification
        {
            AppUserId = Uid, Title = created.Count > 1 ? "Bulk Payment Submitted" : "Payment Submitted",
            Message = $"{created.Count} payment(s) totalling R {created.Sum(p => p.Amount):N2} submitted for confirmation.",
            IconClass = "fa-solid fa-paper-plane"
        });
        await _db.SaveChangesAsync();
        return Ok(new
        {
            total = created.Sum(p => p.Amount),
            payments = created.Select(p => new { p.Id, Service = services[p.EstateServiceId].Name, p.Amount, p.Reference, Status = p.Status.ToString() })
        });
    }

    [HttpGet("notifications")]
    public async Task<IActionResult> Notifications() => Ok(await _db.Notifications.Where(n => n.AppUserId == Uid)
        .OrderByDescending(n => n.CreatedOn).Select(n => new { n.Id, n.Title, n.Message, n.IsRead, n.CreatedOn }).ToListAsync());

    [HttpPost("notifications/read")]
    public async Task<IActionResult> MarkRead()
    {
        await _db.Notifications.Where(n => n.AppUserId == Uid && !n.IsRead).ForEachAsync(n => n.IsRead = true);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}

// ---------------- Officer / Admin reports ----------------

[ApiController]
[Route("api/reports")]
[Authorize(AuthenticationSchemes = ApiRules.Scheme, Roles = "FinancialOfficer,Administrator")]
public class ReportsApiController : ControllerBase
{
    private readonly AppDbContext _db;
    public ReportsApiController(AppDbContext db) => _db = db;

    [HttpGet("summary")]
    public async Task<IActionResult> Summary(DateTime? from, DateTime? to)
    {
        var start = (from ?? new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1)).Date;
        var end = (to ?? DateTime.UtcNow).Date.AddDays(1);
        var p = await _db.Payments.Include(x => x.EstateService).Where(x => x.SubmittedOn >= start && x.SubmittedOn < end).ToListAsync();
        var paid = p.Where(x => x.Status == PaymentStatus.Paid).ToList();
        return Ok(new
        {
            from = start, to = end.AddDays(-1),
            transactions = p.Count,
            collected = paid.Sum(x => x.Amount),
            pending = new { count = p.Count(x => x.Status == PaymentStatus.Pending), value = p.Where(x => x.Status == PaymentStatus.Pending).Sum(x => x.Amount) },
            flagged = new { count = p.Count(x => x.Status == PaymentStatus.Flagged), value = p.Where(x => x.Status == PaymentStatus.Flagged).Sum(x => x.Amount) },
            confirmationRate = p.Count == 0 ? 0 : Math.Round(100.0 * paid.Count / p.Count, 1),
            byService = paid.GroupBy(x => x.EstateService?.Name ?? "Unknown").Select(g => new { service = g.Key, total = g.Sum(x => x.Amount), count = g.Count() }).OrderByDescending(x => x.total),
            byMethod = paid.GroupBy(x => x.Method).Select(g => new { method = g.Key, total = g.Sum(x => x.Amount), count = g.Count() })
        });
    }
}
