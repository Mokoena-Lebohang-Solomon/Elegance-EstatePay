using System.Security.Claims;
using EleganceEstatePay.Data;
using EleganceEstatePay.Models;
using EleganceEstatePay.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EleganceEstatePay.Controllers;

[Authorize(Policy = "OfficerOnly")]
public class OfficerController : Controller
{
    private readonly AppDbContext _db;

    public OfficerController(AppDbContext db) => _db = db;

    private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    public async Task<IActionResult> Index()
    {
        var model = new OfficerDashboardViewModel
        {
            PendingPayments = await _db.Payments
                .Include(p => p.AppUser)
                .Include(p => p.EstateService)
                .Where(p => p.Status == PaymentStatus.Pending)
                .OrderBy(p => p.SubmittedOn)
                .Take(15)
                .ToListAsync(),
            ResidentCount = await _db.Users.CountAsync(u => u.Role == UserRole.Resident),
            AverageRating = await _db.ServiceReviews.AnyAsync(r => r.OfficerUserId == CurrentUserId)
                ? await _db.ServiceReviews.Where(r => r.OfficerUserId == CurrentUserId).AverageAsync(r => (double)r.Stars)
                : 0
        };

        model.PendingCount = await _db.Payments.CountAsync(p => p.Status == PaymentStatus.Pending);
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> AcceptPayment(int id)
    {
        var payment = await _db.Payments
            .Include(p => p.AppUser)
            .Include(p => p.EstateService)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (payment is null) return NotFound();

        ViewBag.Outstanding = await _db.Payments
            .Where(p => p.AppUserId == payment.AppUserId && p.Status == PaymentStatus.Pending)
            .SumAsync(p => (decimal?)p.Amount) ?? 0m;

        ViewBag.LastPayment = await _db.Payments
            .Include(p => p.EstateService)
            .Where(p => p.AppUserId == payment.AppUserId && p.Status == PaymentStatus.Paid)
            .OrderByDescending(p => p.ProcessedOn)
            .FirstOrDefaultAsync();

        return View(payment);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Confirm(int id)
    {
        var payment = await _db.Payments
            .Include(p => p.EstateService)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (payment is null) return NotFound();

        payment.Status = PaymentStatus.Paid;
        payment.ProcessedOn = DateTime.UtcNow;
        payment.ProcessedByUserId = CurrentUserId;

        _db.Notifications.Add(new Notification
        {
            AppUserId = payment.AppUserId,
            Title = "Payment Confirmed",
            Message = $"Your {payment.EstateService?.Name} payment of R {payment.Amount:N2} was received.",
            IconClass = "fa-solid fa-circle-check"
        });

        await _db.SaveChangesAsync();
        TempData["Success"] = "Payment confirmed.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Flag(int id, string? note)
    {
        var payment = await _db.Payments
            .Include(p => p.EstateService)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (payment is null) return NotFound();

        payment.Status = PaymentStatus.Flagged;
        payment.ProcessedOn = DateTime.UtcNow;
        payment.ProcessedByUserId = CurrentUserId;
        payment.OfficerNote = note;

        _db.Notifications.Add(new Notification
        {
            AppUserId = payment.AppUserId,
            Title = "Payment Flagged for Review",
            Message = $"Your {payment.EstateService?.Name} payment of R {payment.Amount:N2} needs attention. {note}".Trim(),
            IconClass = "fa-solid fa-triangle-exclamation"
        });

        await _db.SaveChangesAsync();
        TempData["Success"] = "Payment flagged for review.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Residents(string? q)
    {
        ViewBag.Query = q;

        var query = _db.Users.Where(u => u.Role == UserRole.Resident);

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(u => u.Number.Contains(term) || u.FirstName.Contains(term) || u.Surname.Contains(term));
        }

        return View(await query.OrderBy(u => u.Surname).ToListAsync());
    }

    [HttpGet]
    public async Task<IActionResult> EditResident(int id)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == id && u.Role == UserRole.Resident);
        if (user is null) return NotFound();

        return View(new UserFormViewModel
        {
            Id = user.Id,
            Number = user.Number,
            FirstName = user.FirstName,
            Surname = user.Surname,
            Email = user.Email,
            ContactNumber = user.ContactNumber,
            Role = user.Role,
            ResidentType = user.ResidentType,
            Status = user.Status
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EditResident(UserFormViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == model.Id && u.Role == UserRole.Resident);
        if (user is null) return NotFound();

        user.FirstName = model.FirstName.Trim();
        user.Surname = model.Surname.Trim();
        user.Email = model.Email.Trim();
        user.ContactNumber = model.ContactNumber;
        user.ResidentType = model.ResidentType;
        user.Status = model.Status;

        // Officers assist residents with password resets.
        if (!string.IsNullOrWhiteSpace(model.Password))
        {
            user.PasswordHash = PasswordHasher.Hash(model.Password);

            _db.Notifications.Add(new Notification
            {
                AppUserId = user.Id,
                Title = "Password Reset",
                Message = "A financial officer reset your password. Please sign in and change it.",
                IconClass = "fa-solid fa-key"
            });
        }

        await _db.SaveChangesAsync();
        TempData["Success"] = "Resident details updated.";
        return RedirectToAction(nameof(Residents));
    }

    [HttpGet]
    public IActionResult CreateResident() =>
        View("ResidentForm", new UserFormViewModel { Role = UserRole.Resident });

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateResident(UserFormViewModel model)
    {
        if (string.IsNullOrWhiteSpace(model.Password))
            ModelState.AddModelError(nameof(model.Password), "A password is required for a new account.");

        if (!ModelState.IsValid) return View("ResidentForm", model);

        var number = model.Number.Trim();
        var email = model.Email.Trim();

        if (await _db.Users.AnyAsync(u => u.Number == number))
        {
            ModelState.AddModelError(nameof(model.Number), "That number is already in use.");
            return View("ResidentForm", model);
        }

        if (await _db.Users.AnyAsync(u => u.Email == email))
        {
            ModelState.AddModelError(nameof(model.Email), "That email address is already in use.");
            return View("ResidentForm", model);
        }

        var user = new AppUser
        {
            Number = number,
            FirstName = model.FirstName.Trim(),
            Surname = model.Surname.Trim(),
            Email = email,
            ContactNumber = model.ContactNumber,
            Role = UserRole.Resident,
            ResidentType = model.ResidentType,
            Status = model.Status,
            PasswordHash = PasswordHasher.Hash(model.Password!)
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        _db.Notifications.Add(new Notification
        {
            AppUserId = user.Id,
            Title = "Welcome to Elegance Estate Pay",
            Message = "A financial officer created your estate account. Sign in with your student / staff number.",
            IconClass = "fa-solid fa-user-plus"
        });
        await _db.SaveChangesAsync();

        TempData["Success"] = "Resident account created.";
        return RedirectToAction(nameof(Residents));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteResident(int id)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == id && u.Role == UserRole.Resident);
        if (user is null) return NotFound();

        _db.Users.Remove(user);
        await _db.SaveChangesAsync();

        TempData["Success"] = "Resident account deleted.";
        return RedirectToAction(nameof(Residents));
    }

    public async Task<IActionResult> ViewResident(int id)
    {
        var user = await _db.Users
            .Include(u => u.Payments).ThenInclude(p => p.EstateService)
            .FirstOrDefaultAsync(u => u.Id == id && u.Role == UserRole.Resident);

        if (user is null) return NotFound();
        return View("~/Views/Admin/ViewResident.cshtml", user);
    }

    public async Task<IActionResult> Reviews()
    {
        var reviews = await _db.ServiceReviews
            .Include(r => r.Resident)
            .Include(r => r.Officer)
            .Where(r => r.OfficerUserId == CurrentUserId || User.IsInRole(nameof(UserRole.Administrator)))
            .OrderByDescending(r => r.CreatedOn)
            .ToListAsync();

        return View(reviews);
    }

    public async Task<IActionResult> Reports()
    {
        var monthStart = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1);

        var payments = await _db.Payments
            .Include(p => p.EstateService)
            .Include(p => p.AppUser)
            .Where(p => p.SubmittedOn >= monthStart)
            .OrderByDescending(p => p.SubmittedOn)
            .ToListAsync();

        return View(payments);
    }
}
