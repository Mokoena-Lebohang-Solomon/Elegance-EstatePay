using EleganceEstatePay.Data;
using EleganceEstatePay.Models;
using EleganceEstatePay.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EleganceEstatePay.Controllers;

/// <summary>
/// First-run bootstrap. Lets the very first Administrator (Agent Head) account be created
/// when the database is still empty. It refuses to run once any administrator exists,
/// so no default/demo credentials ever ship with the system.
/// </summary>
public class SetupController : Controller
{
    private readonly AppDbContext _db;

    public SetupController(AppDbContext db) => _db = db;

    private Task<bool> AdminExistsAsync() =>
        _db.Users.AnyAsync(u => u.Role == UserRole.Administrator);

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        if (await AdminExistsAsync()) return RedirectToAction("Login", "Account");
        return View(new RegisterViewModel { ResidentType = ResidentType.Staff });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(RegisterViewModel model)
    {
        if (await AdminExistsAsync()) return RedirectToAction("Login", "Account");
        if (!ModelState.IsValid) return View(model);

        var number = model.Number.Trim();

        if (await _db.Users.AnyAsync(u => u.Number == number))
        {
            ModelState.AddModelError(nameof(model.Number), "That number is already registered.");
            return View(model);
        }

        _db.Users.Add(new AppUser
        {
            Number = number,
            FirstName = model.FirstName.Trim(),
            Surname = model.Surname.Trim(),
            Email = model.Email.Trim(),
            ContactNumber = model.ContactNumber,
            Role = UserRole.Administrator,
            ResidentType = ResidentType.Staff,
            Status = AccountStatus.Active,
            IsAuthorised = true,
            AuthorisedOn = DateTime.UtcNow,
            PasswordHash = PasswordHasher.Hash(model.Password)
        });

        await _db.SaveChangesAsync();

        TempData["Success"] = "Administrator account created. Please sign in.";
        return RedirectToAction("Login", "Account");
    }
}
