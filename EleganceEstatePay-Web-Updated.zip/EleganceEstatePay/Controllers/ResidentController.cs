using System.Security.Claims;
using EleganceEstatePay.Data;
using EleganceEstatePay.Models;
using EleganceEstatePay.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EleganceEstatePay.Controllers;

[Authorize(Policy = "ResidentOnly")]
public class ResidentController : Controller
{
    private readonly AppDbContext _db;

    public ResidentController(AppDbContext db) => _db = db;

    private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    public async Task<IActionResult> Index()
    {
        var user = await _db.Users.FirstAsync(u => u.Id == CurrentUserId);

        var model = new ResidentDashboardViewModel
        {
            Resident = user,
            OutstandingBalance = await _db.Payments
                .Where(p => p.AppUserId == user.Id && (p.Status == PaymentStatus.Pending || p.Status == PaymentStatus.Flagged))
                .SumAsync(p => (decimal?)p.Amount) ?? 0m,
            UnreadNotifications = await _db.Notifications.CountAsync(n => n.AppUserId == user.Id && !n.IsRead),
            RecentPayments = await _db.Payments
                .Include(p => p.EstateService)
                .Where(p => p.AppUserId == user.Id)
                .OrderByDescending(p => p.SubmittedOn)
                .Take(8)
                .ToListAsync()
        };

        model.NextDueDate = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1).AddMonths(1);

        ViewBag.Services = await _db.EstateServices.Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync();
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Pay(int? serviceId, decimal? amount)
    {
        var user = await _db.Users.FirstAsync(u => u.Id == CurrentUserId);
        var services = await _db.EstateServices.Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync();

        var selected = services.FirstOrDefault(s => s.Id == serviceId) ?? services.FirstOrDefault();

        return View(new MakePaymentViewModel
        {
            Services = services,
            EstateServiceId = selected?.Id ?? 0,
            Amount = amount is > 0 ? amount.Value : selected?.Tariff ?? 0,
            BankAccountNumber = user.BankAccountNumber
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Pay(MakePaymentViewModel model)
    {
        model.Services = await _db.EstateServices.Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync();

        var service = model.Services.FirstOrDefault(s => s.Id == model.EstateServiceId);
        if (service is null) ModelState.AddModelError(nameof(model.EstateServiceId), "Choose a service to pay for.");

        if (!ModelState.IsValid || service is null) return View(model);

        if (model.Method == "Card")
        {
            return View("AddCard", new CardPaymentViewModel
            {
                EstateServiceId = service.Id,
                Amount = model.Amount,
                ServiceName = service.Name
            });
        }

        return View("PaymentReview", new PaymentReviewViewModel
        {
            EstateServiceId = service.Id,
            Amount = model.Amount,
            ServiceName = service.Name,
            Method = model.Method
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddCard(CardPaymentViewModel model)
    {
        var service = await _db.EstateServices
            .FirstOrDefaultAsync(s => s.Id == model.EstateServiceId && s.IsActive);

        if (service is null)
        {
            ModelState.AddModelError(nameof(model.EstateServiceId), "That service is no longer available.");
            return View(model);
        }

        if (!ModelState.IsValid)
        {
            model.ServiceName = service.Name;
            return View(model);
        }

        var digits = new string(model.CardNumber.Where(char.IsDigit).ToArray());
        return View("PaymentReview", new PaymentReviewViewModel
        {
            EstateServiceId = service.Id,
            Amount = model.Amount,
            ServiceName = service.Name,
            Method = "Card",
            CardHolder = model.CardHolder.Trim(),
            CardLastFour = digits[^4..]
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> PaymentReview(PaymentReviewViewModel model)
    {
        var service = await _db.EstateServices
            .FirstOrDefaultAsync(s => s.Id == model.EstateServiceId && s.IsActive);

        var allowedMethods = new[] { "Card", "EFT / Bank Transfer", "Debit Order" };

        if (service is null || model.Amount <= 0 || !allowedMethods.Contains(model.Method))
        {
            TempData["Error"] = "The payment details are no longer valid. Please start again.";
            return RedirectToAction(nameof(Pay));
        }

        var payment = new Payment
        {
            AppUserId = CurrentUserId,
            EstateServiceId = service.Id,
            Amount = model.Amount,
            Method = model.Method,
            Reference = ReferenceGenerator.Next(),
            Status = PaymentStatus.Pending,
            SubmittedOn = DateTime.UtcNow
        };

        _db.Payments.Add(payment);
        _db.Notifications.Add(new Notification
        {
            AppUserId = CurrentUserId,
            Title = "Payment Submitted",
            Message = $"Your {service.Name} payment of R {model.Amount:N2} was submitted and is awaiting confirmation.",
            IconClass = "fa-solid fa-paper-plane"
        });

        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(PaymentComplete), new { id = payment.Id });
    }

    [HttpGet]
    public async Task<IActionResult> PaymentComplete(int id)
    {
        var payment = await _db.Payments
            .Include(p => p.EstateService)
            .FirstOrDefaultAsync(p => p.Id == id && p.AppUserId == CurrentUserId);

        if (payment is null) return NotFound();

        return View(new PaymentCompleteViewModel
        {
            Reference = payment.Reference,
            ServiceName = payment.EstateService?.Name ?? "Estate service",
            Amount = payment.Amount,
            Method = payment.Method
        });
    }

    public async Task<IActionResult> History()
    {
        var payments = await _db.Payments
            .Include(p => p.EstateService)
            .Include(p => p.ProcessedBy)
            .Where(p => p.AppUserId == CurrentUserId)
            .OrderByDescending(p => p.SubmittedOn)
            .ToListAsync();

        return View(payments);
    }

    public async Task<IActionResult> Notifications()
    {
        var items = await _db.Notifications
            .Where(n => n.AppUserId == CurrentUserId)
            .OrderByDescending(n => n.CreatedOn)
            .ToListAsync();

        ViewBag.UnreadIds = items.Where(n => !n.IsRead).Select(n => n.Id).ToHashSet();

        foreach (var n in items.Where(n => !n.IsRead))
            n.IsRead = true;

        await _db.SaveChangesAsync();
        return View(items);
    }

    [HttpGet]
    public async Task<IActionResult> Rate(int? paymentId)
    {
        var rateable = await _db.Payments
            .Include(p => p.EstateService)
            .Include(p => p.ProcessedBy)
            .Where(p => p.AppUserId == CurrentUserId && p.Status == PaymentStatus.Paid && p.ProcessedByUserId != null)
            .OrderByDescending(p => p.ProcessedOn)
            .ToListAsync();

        var selected = rateable.FirstOrDefault(p => p.Id == paymentId) ?? rateable.FirstOrDefault();

        return View(new RateServiceViewModel
        {
            RateablePayments = rateable,
            PaymentId = selected?.Id ?? 0,
            OfficerUserId = selected?.ProcessedByUserId ?? 0,
            OfficerName = selected?.ProcessedBy?.FullName ?? "—"
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Rate(RateServiceViewModel model)
    {
        var payment = await _db.Payments
            .Include(p => p.ProcessedBy)
            .FirstOrDefaultAsync(p => p.Id == model.PaymentId && p.AppUserId == CurrentUserId);

        if (payment?.ProcessedByUserId is null)
            ModelState.AddModelError(string.Empty, "Choose a processed payment to review.");

        if (!ModelState.IsValid)
        {
            model.RateablePayments = await _db.Payments
                .Include(p => p.EstateService)
                .Include(p => p.ProcessedBy)
                .Where(p => p.AppUserId == CurrentUserId && p.Status == PaymentStatus.Paid && p.ProcessedByUserId != null)
                .OrderByDescending(p => p.ProcessedOn)
                .ToListAsync();

            return View(model);
        }

        _db.ServiceReviews.Add(new ServiceReview
        {
            ResidentUserId = CurrentUserId,
            OfficerUserId = payment!.ProcessedByUserId!.Value,
            PaymentId = payment.Id,
            Stars = model.Stars,
            Comment = model.Comment
        });

        await _db.SaveChangesAsync();

        TempData["Success"] = "Thank you — your review has been submitted.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Profile()
    {
        var user = await _db.Users.FirstAsync(u => u.Id == CurrentUserId);
        return View(user);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Profile(AppUser model)
    {
        var user = await _db.Users.FirstAsync(u => u.Id == CurrentUserId);

        var emailError = InstitutionalEmail.Error(user.ResidentType, user.Number, model.Surname ?? user.Surname, model.Email ?? "");
        if (emailError != null)
        {
            ModelState.AddModelError(nameof(model.Email), emailError);
            model.Number = user.Number;
            model.ResidentType = user.ResidentType;
            return View(model);
        }

        user.FirstName = model.FirstName?.Trim() ?? user.FirstName;
        user.Surname = model.Surname?.Trim() ?? user.Surname;
        user.Email = model.Email?.Trim() ?? user.Email;
        user.ContactNumber = model.ContactNumber;
        user.BankName = model.BankName;
        user.BankAccountNumber = model.BankAccountNumber;

        await _db.SaveChangesAsync();

        TempData["Success"] = "Profile updated.";
        return RedirectToAction(nameof(Profile));
    }

    [HttpGet]
    public async Task<IActionResult> Calculator()
    {
        var services = await _db.EstateServices
            .Where(s => s.IsActive)
            .OrderBy(s => s.Name)
            .ToListAsync();

        var outstanding = await _db.Payments
            .Where(p => p.AppUserId == CurrentUserId && p.Status == PaymentStatus.Pending)
            .SumAsync(p => (decimal?)p.Amount) ?? 0m;

        return View(new RateCalculatorViewModel
        {
            Services = services,
            OutstandingBalance = outstanding
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> BulkPay()
    {
        // Each row posts "selected" (service id, only when ticked) and "amount_{id}" (always),
        // so ids and amounts can never fall out of step.
        var selectedIds = Request.Form["selected"]
            .Select(v => int.TryParse(v, out var id) ? id : 0)
            .Where(id => id > 0)
            .Distinct()
            .ToList();

        if (selectedIds.Count == 0)
        {
            TempData["Error"] = "Select a service: tick at least one service with an amount above zero.";
            return RedirectToAction(nameof(Calculator));
        }

        var services = await _db.EstateServices
            .Where(s => s.IsActive && selectedIds.Contains(s.Id))
            .ToDictionaryAsync(s => s.Id);

        var items = new List<BulkPaymentItemViewModel>();
        foreach (var id in selectedIds)
        {
            if (!services.TryGetValue(id, out var service)) continue;
            var raw = (Request.Form[$"amount_{id}"].ToString() ?? "").Replace(',', '.');
            if (!decimal.TryParse(raw, System.Globalization.NumberStyles.Number,
                    System.Globalization.CultureInfo.InvariantCulture, out var amount)) continue;
            if (amount <= 0) continue;
            items.Add(new BulkPaymentItemViewModel
            {
                EstateServiceId = id,
                ServiceName = service.Name,
                Amount = decimal.Round(amount, 2)
            });
        }

        if (items.Count == 0)
        {
            TempData["Error"] = "Enter a value above zero for a service before paying.";
            return RedirectToAction(nameof(Calculator));
        }

        return View(new BulkPaymentViewModel { Items = items });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SubmitBulkPayment(BulkPaymentViewModel model)
    {
        var allowedMethods = new[] { "Card", "EFT / Bank Transfer", "Debit Order" };
        if (model.Items.Count == 0 || !allowedMethods.Contains(model.Method) || model.Items.Any(i => i.Amount <= 0))
        {
            TempData["Error"] = "The selected payment details are invalid. Please calculate them again.";
            return RedirectToAction(nameof(Calculator));
        }

        string? cardLastFour = null;
        if (model.Method == "Card")
        {
            // Re-use the single-payment card rules (number, MM/YY, CVC, not expired).
            var card = new CardPaymentViewModel
            {
                EstateServiceId = model.Items[0].EstateServiceId,
                Amount = model.Total,
                ServiceName = "Multiple services",
                CardHolder = model.CardHolder?.Trim() ?? string.Empty,
                CardNumber = model.CardNumber ?? string.Empty,
                ExpiryDate = model.ExpiryDate ?? string.Empty,
                Cvc = model.Cvc ?? string.Empty
            };
            var results = new List<System.ComponentModel.DataAnnotations.ValidationResult>();
            if (!System.ComponentModel.DataAnnotations.Validator.TryValidateObject(
                    card, new System.ComponentModel.DataAnnotations.ValidationContext(card), results, validateAllProperties: true))
            {
                ModelState.Clear();
                foreach (var r in results)
                {
                    var key = r.MemberNames.FirstOrDefault() ?? string.Empty;
                    ModelState.AddModelError(key, r.ErrorMessage ?? "Invalid card details.");
                }
                return View("BulkPay", model);
            }
            var digits = new string(card.CardNumber.Where(char.IsDigit).ToArray());
            cardLastFour = digits[^4..];
        }

        var ids = model.Items.Select(i => i.EstateServiceId).Distinct().ToArray();
        var services = await _db.EstateServices.Where(s => s.IsActive && ids.Contains(s.Id)).ToDictionaryAsync(s => s.Id);
        if (services.Count != ids.Length)
        {
            TempData["Error"] = "One of the selected services is no longer available.";
            return RedirectToAction(nameof(Calculator));
        }

        var references = new List<string>();
        foreach (var item in model.Items)
        {
            var reference = ReferenceGenerator.Next();
            references.Add(reference);
            _db.Payments.Add(new Payment
            {
                AppUserId = CurrentUserId,
                EstateServiceId = item.EstateServiceId,
                Amount = decimal.Round(item.Amount, 2),
                Method = model.Method,
                Reference = reference,
                Status = PaymentStatus.Pending,
                SubmittedOn = DateTime.UtcNow
            });
        }

        _db.Notifications.Add(new Notification
        {
            AppUserId = CurrentUserId,
            Title = "Bulk Payment Submitted",
            Message = $"{model.Items.Count} service payments totalling R {model.Total:N2} were submitted for confirmation"
                      + (cardLastFour is null ? "." : $" (card ending {cardLastFour})."),
            IconClass = "fa-solid fa-layer-group"
        });
        await _db.SaveChangesAsync();

        TempData["Success"] = $"{model.Items.Count} payments submitted. References: {string.Join(", ", references)}";
        return RedirectToAction(nameof(History));
    }
}
