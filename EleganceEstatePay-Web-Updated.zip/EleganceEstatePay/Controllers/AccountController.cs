using System.Security.Claims;
using EleganceEstatePay.Data;
using EleganceEstatePay.Models;
using EleganceEstatePay.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EleganceEstatePay.Controllers;

public class AccountController : Controller
{
    private readonly AppDbContext _db;
    public AccountController(AppDbContext db) => _db = db;

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (User.Identity?.IsAuthenticated ?? false)
            return RedirectToAction("Index", "Home");

        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var number = model.Number.Trim();
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Number == number);

        if (user is null || !PasswordHasher.Verify(model.Password, user.PasswordHash))
        {
            ModelState.AddModelError(string.Empty, "Invalid student/staff number or password.");
            return View(model);
        }

        if (user.Status != AccountStatus.Active)
        {
            ModelState.AddModelError(string.Empty, "This account is not active. Please contact the estate administrator.");
            return View(model);
        }

        if (user.Role == UserRole.FinancialOfficer && !user.IsAuthorised)
        {
            ModelState.AddModelError(string.Empty, "Your officer account has not been authorised by the administrator yet.");
            return View(model);
        }

        await SignInAsync(user, model.RememberMe);

        if (!string.IsNullOrWhiteSpace(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            return Redirect(model.ReturnUrl);

        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    public IActionResult Register() => View(new RegisterViewModel());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var number = model.Number.Trim();
        var email = model.Email.Trim();

        if (await _db.Users.AnyAsync(u => u.Number == number))
            ModelState.AddModelError(nameof(model.Number), "That student/staff number is already registered.");

        if (await _db.Users.AnyAsync(u => u.Email == email))
            ModelState.AddModelError(nameof(model.Email), "That email address is already registered.");

        if (!ModelState.IsValid) return View(model);

        var user = new AppUser
        {
            Number = number,
            FirstName = model.FirstName.Trim(),
            Surname = model.Surname.Trim(),
            Email = email,
            ContactNumber = model.ContactNumber,
            ResidentType = model.ResidentType,
            Role = UserRole.Resident,
            Status = AccountStatus.Active,
            PasswordHash = PasswordHasher.Hash(model.Password)
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        _db.Notifications.Add(new Notification
        {
            AppUserId = user.Id,
            Title = "Welcome to Elegance EstatePay",
            Message = "Your resident account has been created and is ready to use.",
            IconClass = "fa-solid fa-circle-check"
        });
        await _db.SaveChangesAsync();

        TempData["Success"] = "Your account has been created. Sign in with your student or staff number.";
        return RedirectToAction(nameof(Login));
    }


    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction(nameof(Login));
    }

    [HttpGet]
    public IActionResult Denied() => View();

    [Authorize]
    [HttpGet]
    public IActionResult ChangePassword() => View(new ChangePasswordViewModel());

    [Authorize]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = await CurrentUserAsync();
        if (user is null) return Challenge();

        if (!PasswordHasher.Verify(model.CurrentPassword, user.PasswordHash))
        {
            ModelState.AddModelError(nameof(model.CurrentPassword), "Your current password is incorrect.");
            return View(model);
        }

        user.PasswordHash = PasswordHasher.Hash(model.NewPassword);
        await _db.SaveChangesAsync();

        await SignInAsync(user, false);

        TempData["Success"] = "Your password has been updated.";
        return RedirectToAction("Index", "Home");
    }

    private async Task<AppUser?> CurrentUserAsync()
    {
        var id = User.FindFirstValue(ClaimTypes.NameIdentifier);
        return int.TryParse(id, out var userId)
            ? await _db.Users.FirstOrDefaultAsync(u => u.Id == userId)
            : null;
    }

    private async Task SignInAsync(AppUser user, bool persistent)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.FullName),
            new("Number", user.Number),
            new(ClaimTypes.Role, user.Role.ToString())
        };

        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(identity),
            new AuthenticationProperties { IsPersistent = persistent });
    }
}
