/* =====================================================================
   Elegance EstatePay — Microsoft SQL Server schema
   CSIQ 3784 Software Engineering Project
   NOTE: schema only. No demo / seed data is inserted.
   ===================================================================== */

IF DB_ID('EleganceEstatePay') IS NULL
    CREATE DATABASE EleganceEstatePay;
GO

USE EleganceEstatePay;
GO

IF OBJECT_ID('dbo.ServiceReviews', 'U') IS NOT NULL DROP TABLE dbo.ServiceReviews;
IF OBJECT_ID('dbo.Notifications', 'U') IS NOT NULL DROP TABLE dbo.Notifications;
IF OBJECT_ID('dbo.Payments', 'U') IS NOT NULL DROP TABLE dbo.Payments;
IF OBJECT_ID('dbo.EstateServices', 'U') IS NOT NULL DROP TABLE dbo.EstateServices;
IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL DROP TABLE dbo.Users;
GO

/* ---------------------------------------------------------------------
   Users — residents (students & staff), financial officers, admin.
   Role:          0 = Resident, 1 = FinancialOfficer, 2 = Administrator
   ResidentType:  0 = Student,  1 = Staff,            2 = NotApplicable
   Status:        0 = Active,   1 = Suspended,        2 = Deactivated
   Login is performed with Number (student / staff number) + password.
   --------------------------------------------------------------------- */
CREATE TABLE dbo.Users
(
    Id                INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
    Number            NVARCHAR(20)  NOT NULL,
    FirstName         NVARCHAR(80)  NOT NULL,
    Surname           NVARCHAR(80)  NOT NULL,
    Email             NVARCHAR(160) NOT NULL,
    ContactNumber     NVARCHAR(30)  NULL,
    [Role]            INT           NOT NULL CONSTRAINT DF_Users_Role DEFAULT (0),
    ResidentType      INT           NOT NULL CONSTRAINT DF_Users_Type DEFAULT (0),
    [Status]          INT           NOT NULL CONSTRAINT DF_Users_Status DEFAULT (0),
    PasswordHash      NVARCHAR(256) NOT NULL,
    BankAccountNumber NVARCHAR(64)  NULL,
    BankName          NVARCHAR(80)  NULL,
    IsAuthorised      BIT           NOT NULL CONSTRAINT DF_Users_Auth DEFAULT (0),
    AuthorisedOn      DATETIME2     NULL,
    Permissions       NVARCHAR(200) NULL,
    CreatedOn         DATETIME2     NOT NULL CONSTRAINT DF_Users_Created DEFAULT (SYSUTCDATETIME())
);
GO

CREATE UNIQUE INDEX IX_Users_Number ON dbo.Users(Number);
CREATE UNIQUE INDEX IX_Users_Email  ON dbo.Users(Email);
GO

/* ---------------------------------------------------------------------
   EstateServices — water, electricity, parking, refuse, rent.
   Tariffs are captured by the administrator from Settings; none seeded.
   --------------------------------------------------------------------- */
CREATE TABLE dbo.EstateServices
(
    Id            INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_EstateServices PRIMARY KEY,
    Name          NVARCHAR(60)   NOT NULL,
    [Description] NVARCHAR(200)  NULL,
    Tariff        DECIMAL(18,2)  NOT NULL CONSTRAINT DF_Services_Tariff DEFAULT (0),
    BillingPeriod NVARCHAR(40)   NOT NULL CONSTRAINT DF_Services_Period DEFAULT ('Monthly'),
    IconClass     NVARCHAR(40)   NOT NULL CONSTRAINT DF_Services_Icon DEFAULT ('fa-solid fa-house'),
    IsActive      BIT            NOT NULL CONSTRAINT DF_Services_Active DEFAULT (1)
);
GO

/* ---------------------------------------------------------------------
   Payments — Status: 0 = Pending, 1 = Paid, 2 = Flagged, 3 = Rejected
   --------------------------------------------------------------------- */
CREATE TABLE dbo.Payments
(
    Id                INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Payments PRIMARY KEY,
    AppUserId         INT            NOT NULL,
    EstateServiceId   INT            NOT NULL,
    Amount            DECIMAL(18,2)  NOT NULL,
    Method            NVARCHAR(40)   NOT NULL CONSTRAINT DF_Payments_Method DEFAULT ('EFT'),
    Reference         NVARCHAR(40)   NOT NULL,
    [Status]          INT            NOT NULL CONSTRAINT DF_Payments_Status DEFAULT (0),
    SubmittedOn       DATETIME2      NOT NULL CONSTRAINT DF_Payments_Submitted DEFAULT (SYSUTCDATETIME()),
    ProcessedOn       DATETIME2      NULL,
    ProcessedByUserId INT            NULL,
    OfficerNote       NVARCHAR(400)  NULL,
    CONSTRAINT FK_Payments_User      FOREIGN KEY (AppUserId)         REFERENCES dbo.Users(Id) ON DELETE CASCADE,
    CONSTRAINT FK_Payments_Service   FOREIGN KEY (EstateServiceId)   REFERENCES dbo.EstateServices(Id),
    CONSTRAINT FK_Payments_Officer   FOREIGN KEY (ProcessedByUserId) REFERENCES dbo.Users(Id)
);
GO

CREATE UNIQUE INDEX IX_Payments_Reference ON dbo.Payments(Reference);
CREATE INDEX IX_Payments_User ON dbo.Payments(AppUserId);
CREATE INDEX IX_Payments_Status ON dbo.Payments([Status]);
GO

CREATE TABLE dbo.Notifications
(
    Id         INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Notifications PRIMARY KEY,
    AppUserId  INT            NOT NULL,
    Title      NVARCHAR(120)  NOT NULL,
    [Message]  NVARCHAR(400)  NOT NULL,
    IconClass  NVARCHAR(40)   NOT NULL CONSTRAINT DF_Notif_Icon DEFAULT ('fa-solid fa-bell'),
    IsRead     BIT            NOT NULL CONSTRAINT DF_Notif_Read DEFAULT (0),
    CreatedOn  DATETIME2      NOT NULL CONSTRAINT DF_Notif_Created DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Notifications_User FOREIGN KEY (AppUserId) REFERENCES dbo.Users(Id) ON DELETE CASCADE
);
GO

CREATE TABLE dbo.ServiceReviews
(
    Id             INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ServiceReviews PRIMARY KEY,
    ResidentUserId INT           NOT NULL,
    OfficerUserId  INT           NOT NULL,
    PaymentId      INT           NULL,
    Stars          INT           NOT NULL CONSTRAINT CK_Reviews_Stars CHECK (Stars BETWEEN 1 AND 5),
    Comment        NVARCHAR(600) NULL,
    CreatedOn      DATETIME2     NOT NULL CONSTRAINT DF_Reviews_Created DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Reviews_Resident FOREIGN KEY (ResidentUserId) REFERENCES dbo.Users(Id),
    CONSTRAINT FK_Reviews_Officer  FOREIGN KEY (OfficerUserId)  REFERENCES dbo.Users(Id),
    CONSTRAINT FK_Reviews_Payment  FOREIGN KEY (PaymentId)      REFERENCES dbo.Payments(Id)
);
GO

/* Reporting helper: monthly collections per service. */
CREATE OR ALTER VIEW dbo.vw_MonthlyCollections
AS
SELECT
    s.Name                       AS ServiceName,
    YEAR(p.SubmittedOn)          AS [Year],
    MONTH(p.SubmittedOn)         AS [Month],
    SUM(p.Amount)                AS TotalCollected,
    COUNT(*)                     AS TransactionCount
FROM dbo.Payments p
INNER JOIN dbo.EstateServices s ON s.Id = p.EstateServiceId
WHERE p.[Status] = 1
GROUP BY s.Name, YEAR(p.SubmittedOn), MONTH(p.SubmittedOn);
GO

/* No INSERT statements: the database ships empty by design. */
