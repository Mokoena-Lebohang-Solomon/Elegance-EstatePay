/* Optional upgrade for databases created by an older project version. */
IF COL_LENGTH('dbo.Users', 'EstateUnit') IS NOT NULL
    ALTER TABLE dbo.Users DROP COLUMN EstateUnit;
GO