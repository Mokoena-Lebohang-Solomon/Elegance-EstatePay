using System.Security.Cryptography;

namespace EleganceEstatePay.Services;

public static class ReferenceGenerator
{
    public static string Next() => $"#{RandomNumberGenerator.GetInt32(100000, 999999)}";
}
