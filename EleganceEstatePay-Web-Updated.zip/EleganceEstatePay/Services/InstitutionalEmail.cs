using System.Text.RegularExpressions;
using EleganceEstatePay.Models;

namespace EleganceEstatePay.Services;

/// <summary>Students: {studentnumber}@ufs4life.ac.za (digits only). Staff: {surname}@ufs.ac.za only, e.g. miyals@ufs.ac.za.</summary>
public static class InstitutionalEmail
{
    public static string Expected(ResidentType type, string number, string surname) =>
        type == ResidentType.Student
            ? $"{number.Trim().ToLowerInvariant()}@ufs4life.ac.za"
            : $"{Regex.Replace(surname.Trim().ToLowerInvariant(), @"\s+", "")}@ufs.ac.za";

    public static string? Error(ResidentType type, string number, string surname, string email)
    {
        if (type == ResidentType.Student && !Regex.IsMatch(number.Trim(), @"^\d{6,12}$"))
            return "Student numbers must contain digits only, e.g. 2020708265.";
        var expected = Expected(type, number, surname);
        return string.Equals(email.Trim(), expected, StringComparison.OrdinalIgnoreCase)
            ? null
            : $"Use your institutional email address: {expected}";
    }
}
