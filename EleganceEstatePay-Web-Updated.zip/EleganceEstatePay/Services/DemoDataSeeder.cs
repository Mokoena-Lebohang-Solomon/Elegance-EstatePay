using EleganceEstatePay.Data;
using EleganceEstatePay.Models;
using Microsoft.EntityFrameworkCore;

namespace EleganceEstatePay.Services;

/// <summary>
/// Creates the demo administrator / financial officer logins and the standard
/// estate service tariffs so that payments and the rate calculator work immediately.
/// Every insert is idempotent: existing records are never overwritten.
/// </summary>
public static class DemoDataSeeder
{
    public const string AdminNumber = "ADMIN001";
    public const string AdminPassword = "Admin@123";
    public const string OfficerOneNumber = "FO1001";
    public const string OfficerTwoNumber = "FO1002";
    public const string OfficerPassword = "Officer@123";

    public static void Seed(AppDbContext db)
    {
        SeedServices(db);
        SeedStaff(db);
        db.SaveChanges();
    }

    private static void SeedServices(AppDbContext db)
    {
        var defaults = new[]
        {
            new EstateService { Name = "Water", Description = "Municipal water usage", Tariff = 3.20m, BillingPeriod = "Per kL", IconClass = "fa-solid fa-droplet" },
            new EstateService { Name = "Electricity", Description = "Prepaid electricity units", Tariff = 2.85m, BillingPeriod = "Per kWh", IconClass = "fa-solid fa-bolt" },
            new EstateService { Name = "Parking", Description = "Second vehicle parking bay", Tariff = 150m, BillingPeriod = "Monthly", IconClass = "fa-solid fa-square-parking" },
            new EstateService { Name = "Refuse", Description = "Waste removal", Tariff = 180m, BillingPeriod = "Monthly", IconClass = "fa-solid fa-trash" },
            new EstateService { Name = "Rent", Description = "Monthly estate rental", Tariff = 3200m, BillingPeriod = "Monthly", IconClass = "fa-solid fa-house" },
            new EstateService { Name = "Levy", Description = "Estate maintenance levy", Tariff = 450m, BillingPeriod = "Monthly", IconClass = "fa-solid fa-screwdriver-wrench" },
            new EstateService { Name = "Security", Description = "24/7 estate security", Tariff = 260m, BillingPeriod = "Monthly", IconClass = "fa-solid fa-shield-halved" }
        };

        foreach (var s in defaults)
        {
            if (!db.EstateServices.Any(x => x.Name == s.Name))
                db.EstateServices.Add(s);
        }
    }

    private static void SeedStaff(AppDbContext db)
    {
        AddUser(db, new AppUser
        {
            Number = AdminNumber,
            FirstName = "Estate",
            Surname = "Administrator",
            Email = "admin@eleganceestate.co.za",
            ContactNumber = "051 401 0000",
            Role = UserRole.Administrator,
            ResidentType = ResidentType.Staff,
            Status = AccountStatus.Active,
            IsAuthorised = true,
            AuthorisedOn = DateTime.UtcNow,
            PasswordHash = PasswordHasher.Hash(AdminPassword)
        });

        AddUser(db, new AppUser
        {
            Number = OfficerOneNumber,
            FirstName = "Amanda",
            Surname = "Khumalo",
            Email = "amanda.khumalo@eleganceestate.co.za",
            ContactNumber = "051 401 0011",
            Role = UserRole.FinancialOfficer,
            ResidentType = ResidentType.Staff,
            Status = AccountStatus.Active,
            IsAuthorised = true,
            AuthorisedOn = DateTime.UtcNow,
            PasswordHash = PasswordHasher.Hash(OfficerPassword)
        });

        AddUser(db, new AppUser
        {
            Number = OfficerTwoNumber,
            FirstName = "Sipho",
            Surname = "Ndlovu",
            Email = "sipho.ndlovu@eleganceestate.co.za",
            ContactNumber = "051 401 0012",
            Role = UserRole.FinancialOfficer,
            ResidentType = ResidentType.Staff,
            Status = AccountStatus.Active,
            IsAuthorised = true,
            AuthorisedOn = DateTime.UtcNow,
            PasswordHash = PasswordHasher.Hash(OfficerPassword)
        });
    }

    private static void AddUser(AppDbContext db, AppUser user)
    {
        if (db.Users.Any(u => u.Number == user.Number || u.Email == user.Email)) return;
        db.Users.Add(user);
    }
}
