using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EleganceEstatePay.Models;

public enum UserRole
{
    Resident = 0,
    FinancialOfficer = 1,
    Administrator = 2
}

public enum ResidentType
{
    Student = 0,
    Staff = 1,
    NotApplicable = 2
}

public enum AccountStatus
{
    Active = 0,
    Suspended = 1,
    Deactivated = 2
}

public enum PaymentStatus
{
    Pending = 0,
    Paid = 1,
    Flagged = 2,
    Rejected = 3
}

/// <summary>Single account table for residents, financial officers and the agent head.</summary>
public class AppUser
{
    public int Id { get; set; }

    /// <summary>Student number (e.g. 22045678) or staff/personal number (e.g. S00981). Used to log in.</summary>
    [Required, StringLength(20)]
    public string Number { get; set; } = string.Empty;

    [Required, StringLength(80)]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(80)]
    public string Surname { get; set; } = string.Empty;

    [Required, StringLength(160)]
    public string Email { get; set; } = string.Empty;

    [StringLength(30)]
    public string? ContactNumber { get; set; }

    public UserRole Role { get; set; } = UserRole.Resident;

    public ResidentType ResidentType { get; set; } = ResidentType.Student;

    public AccountStatus Status { get; set; } = AccountStatus.Active;

    /// <summary>PBKDF2 hash, base64 encoded, stored as {iterations}.{salt}.{hash}.</summary>
    [Required, StringLength(256)]
    public string PasswordHash { get; set; } = string.Empty;

    [StringLength(64)]
    public string? BankAccountNumber { get; set; }

    [StringLength(80)]
    public string? BankName { get; set; }

    /// <summary>Only meaningful for financial officers: set by the administrator.</summary>
    public bool IsAuthorised { get; set; }

    public DateTime? AuthorisedOn { get; set; }

    [StringLength(200)]
    public string? Permissions { get; set; }

    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;

    [NotMapped]
    public string FullName => $"{FirstName} {Surname}".Trim();

    public ICollection<Payment> Payments { get; set; } = new List<Payment>();
    public ICollection<Notification> Notifications { get; set; } = new List<Notification>();
}

/// <summary>Billable estate service with its tariff (water, electricity, parking, refuse, rent).</summary>
public class EstateService
{
    public int Id { get; set; }

    [Required, StringLength(60)]
    public string Name { get; set; } = string.Empty;

    [StringLength(200)]
    public string? Description { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal Tariff { get; set; }

    [StringLength(40)]
    public string BillingPeriod { get; set; } = "Monthly";

    [StringLength(40)]
    public string IconClass { get; set; } = "fa-solid fa-house";

    public bool IsActive { get; set; } = true;
}

public class Payment
{
    public int Id { get; set; }

    public int AppUserId { get; set; }
    public AppUser? AppUser { get; set; }

    public int EstateServiceId { get; set; }
    public EstateService? EstateService { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal Amount { get; set; }

    [Required, StringLength(40)]
    public string Method { get; set; } = "EFT / Bank Transfer";

    [Required, StringLength(40)]
    public string Reference { get; set; } = string.Empty;

    public PaymentStatus Status { get; set; } = PaymentStatus.Pending;

    public DateTime SubmittedOn { get; set; } = DateTime.UtcNow;

    public DateTime? ProcessedOn { get; set; }

    /// <summary>Financial officer that confirmed or flagged the payment.</summary>
    public int? ProcessedByUserId { get; set; }
    public AppUser? ProcessedBy { get; set; }

    [StringLength(400)]
    public string? OfficerNote { get; set; }
}

public class Notification
{
    public int Id { get; set; }

    public int AppUserId { get; set; }
    public AppUser? AppUser { get; set; }

    [Required, StringLength(120)]
    public string Title { get; set; } = string.Empty;

    [Required, StringLength(400)]
    public string Message { get; set; } = string.Empty;

    [StringLength(40)]
    public string IconClass { get; set; } = "fa-solid fa-bell";

    public bool IsRead { get; set; }

    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
}

public class ServiceReview
{
    public int Id { get; set; }

    public int ResidentUserId { get; set; }
    public AppUser? Resident { get; set; }

    public int OfficerUserId { get; set; }
    public AppUser? Officer { get; set; }

    public int? PaymentId { get; set; }
    public Payment? Payment { get; set; }

    [Range(1, 5)]
    public int Stars { get; set; }

    [StringLength(600)]
    public string? Comment { get; set; }

    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
}
