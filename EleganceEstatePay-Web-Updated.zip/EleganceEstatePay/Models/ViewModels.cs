using System.ComponentModel.DataAnnotations;

namespace EleganceEstatePay.Models;

public class LoginViewModel
{
    [Required(ErrorMessage = "Enter your student / staff number")]
    [Display(Name = "Student / Staff Number")]
    public string Number { get; set; } = string.Empty;

    [Required(ErrorMessage = "Enter your password")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;

    public bool RememberMe { get; set; }

    public string? ReturnUrl { get; set; }
}

public class RegisterViewModel : IValidatableObject
{
    [Required, Display(Name = "Full Name")]
    public string FirstName { get; set; } = string.Empty;

    [Required]
    public string Surname { get; set; } = string.Empty;

    [Display(Name = "Role")]
    public ResidentType ResidentType { get; set; } = ResidentType.Student;

    [Required, Display(Name = "Student / Staff Number")]
    public string Number { get; set; } = string.Empty;

    [Display(Name = "Contact Number")]
    [Phone]
    public string? ContactNumber { get; set; }

    [Required, EmailAddress, Display(Name = "Email Address")]
    public string Email { get; set; } = string.Empty;

    [Required, DataType(DataType.Password), MinLength(6)]
    public string Password { get; set; } = string.Empty;

    [DataType(DataType.Password), Compare(nameof(Password), ErrorMessage = "Passwords do not match")]
    [Display(Name = "Confirm Password")]
    public string ConfirmPassword { get; set; } = string.Empty;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        var error = EleganceEstatePay.Services.InstitutionalEmail.Error(ResidentType, Number, Surname, Email);
        if (error != null)
            yield return new ValidationResult(error, new[] { nameof(Email) });
    }
}

public class ChangePasswordViewModel
{
    [Required, DataType(DataType.Password), Display(Name = "Current Password")]
    public string CurrentPassword { get; set; } = string.Empty;

    [Required, DataType(DataType.Password), MinLength(6), Display(Name = "New Password")]
    public string NewPassword { get; set; } = string.Empty;

    [DataType(DataType.Password), Compare(nameof(NewPassword))]
    [Display(Name = "Confirm New Password")]
    public string ConfirmPassword { get; set; } = string.Empty;
}

public class UserFormViewModel : IValidatableObject
{
    public int Id { get; set; }

    [Required, Display(Name = "Student / Staff Number")]
    public string Number { get; set; } = string.Empty;

    [Required, Display(Name = "Name")]
    public string FirstName { get; set; } = string.Empty;

    [Required]
    public string Surname { get; set; } = string.Empty;

    [Required, EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Display(Name = "Contact Number")]
    public string? ContactNumber { get; set; }

    public UserRole Role { get; set; } = UserRole.Resident;

    [Display(Name = "Type")]
    public ResidentType ResidentType { get; set; } = ResidentType.Student;

    public AccountStatus Status { get; set; } = AccountStatus.Active;

    [DataType(DataType.Password)]
    [Display(Name = "Password (leave blank to keep current)")]
    public string? Password { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (Role == UserRole.Administrator) yield break;
        var type = Role == UserRole.FinancialOfficer ? ResidentType.Staff : ResidentType;
        var error = EleganceEstatePay.Services.InstitutionalEmail.Error(type, Number, Surname, Email);
        if (error != null)
            yield return new ValidationResult(error, new[] { nameof(Email) });
    }
}

public class AdminDashboardViewModel
{
    public int TotalResidents { get; set; }
    public int ActiveOfficers { get; set; }
    public decimal PaymentsToday { get; set; }
    public int PendingReviews { get; set; }
    public List<Payment> RecentActivity { get; set; } = new();
}

public class ReportsViewModel
{
    public decimal TotalCollected { get; set; }
    public decimal PendingValue { get; set; }
    public decimal FlaggedValue { get; set; }
    public int TransactionCount { get; set; }
    public int ConfirmedCount { get; set; }
    public int PendingCount { get; set; }
    public int FlaggedCount { get; set; }
    public DateTime From { get; set; }
    public DateTime To { get; set; }
    public double OnTimeRate { get; set; }
    public double AverageOfficerRating { get; set; }
    public List<ServiceTotal> CollectionsByService { get; set; } = new();
    public List<ServiceTotal> CollectionsByMethod { get; set; } = new();

    public class ServiceTotal
    {
        public string Service { get; set; } = string.Empty;
        public decimal Total { get; set; }
        public double Percentage { get; set; }
    }
}

public class OfficerDashboardViewModel
{
    public List<Payment> PendingPayments { get; set; } = new();
    public int PendingCount { get; set; }
    public int ResidentCount { get; set; }
    public double AverageRating { get; set; }
}

public class ResidentDashboardViewModel
{
    public AppUser Resident { get; set; } = null!;
    public decimal OutstandingBalance { get; set; }
    public DateTime? NextDueDate { get; set; }
    public int UnreadNotifications { get; set; }
    public List<Payment> RecentPayments { get; set; } = new();
}

public class MakePaymentViewModel
{
    public int EstateServiceId { get; set; }

    [Range(0.01, 1000000, ErrorMessage = "Enter a valid amount")]
    public decimal Amount { get; set; }

    [Required]
    public string Method { get; set; } = "EFT / Bank Transfer";

    public List<EstateService> Services { get; set; } = new();

    public string? BankAccountNumber { get; set; }
}

public class CardPaymentViewModel : IValidatableObject
{
    public int EstateServiceId { get; set; }

    [Range(0.01, 1000000, ErrorMessage = "Enter a valid amount")]
    public decimal Amount { get; set; }

    public string ServiceName { get; set; } = string.Empty;

    [Required, Display(Name = "Account Name"), StringLength(120)]
    public string CardHolder { get; set; } = string.Empty;

    [Required, Display(Name = "Card Number")]
    [RegularExpression(@"^(?:\d[ -]*?){13,19}$", ErrorMessage = "Enter a valid card number")]
    public string CardNumber { get; set; } = string.Empty;

    [Required, Display(Name = "Expiry Date")]
    [RegularExpression(@"^(0[1-9]|1[0-2])\/\d{2}$", ErrorMessage = "Use MM/YY")]
    public string ExpiryDate { get; set; } = string.Empty;

    [Required, Display(Name = "CVC")]
    [RegularExpression(@"^\d{3,4}$", ErrorMessage = "Enter a valid CVC")]
    public string Cvc { get; set; } = string.Empty;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        var digits = new string(CardNumber.Where(char.IsDigit).ToArray());
        if (!IsValidCardNumber(digits))
            yield return new ValidationResult("Enter a valid card number.", new[] { nameof(CardNumber) });

        if (DateTime.TryParseExact(ExpiryDate, "MM/yy", null, System.Globalization.DateTimeStyles.None, out var expiry))
        {
            var endOfMonth = expiry.AddMonths(1).AddDays(-1);
            if (endOfMonth < DateTime.Today)
                yield return new ValidationResult("The card has expired.", new[] { nameof(ExpiryDate) });
        }
    }

    private static bool IsValidCardNumber(string digits)
    {
        if (digits.Length is < 13 or > 19 || digits.Distinct().Count() == 1) return false;
        var sum = 0;
        var alternate = false;
        for (var i = digits.Length - 1; i >= 0; i--)
        {
            var n = digits[i] - '0';
            if (alternate) { n *= 2; if (n > 9) n -= 9; }
            sum += n;
            alternate = !alternate;
        }
        return sum % 10 == 0;
    }
}

public class BulkPaymentItemViewModel
{
    public int EstateServiceId { get; set; }
    public string ServiceName { get; set; } = string.Empty;
    [Range(0.01, 1000000)] public decimal Amount { get; set; }
}

public class BulkPaymentViewModel
{
    public List<BulkPaymentItemViewModel> Items { get; set; } = new();
    [Required] public string Method { get; set; } = "EFT / Bank Transfer";
    public decimal Total => Items.Sum(i => i.Amount);

    // Card details — only required when Method == "Card". Never stored.
    [Display(Name = "Account Name"), StringLength(120)] public string? CardHolder { get; set; }
    [Display(Name = "Card Number")] public string? CardNumber { get; set; }
    [Display(Name = "Expiry Date")] public string? ExpiryDate { get; set; }
    [Display(Name = "CVC")] public string? Cvc { get; set; }
}

public class PaymentReviewViewModel
{
    public int EstateServiceId { get; set; }
    public decimal Amount { get; set; }
    public string ServiceName { get; set; } = string.Empty;
    public string Method { get; set; } = string.Empty;
    public string CardHolder { get; set; } = string.Empty;
    public string CardLastFour { get; set; } = string.Empty;
}

public class PaymentCompleteViewModel
{
    public string Reference { get; set; } = string.Empty;
    public string ServiceName { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Method { get; set; } = string.Empty;
}

public class RateServiceViewModel
{
    public int PaymentId { get; set; }
    public int OfficerUserId { get; set; }
    public string OfficerName { get; set; } = string.Empty;

    [Range(1, 5, ErrorMessage = "Please choose a star rating")]
    public int Stars { get; set; }

    [StringLength(600)]
    public string? Comment { get; set; }

    public List<Payment> RateablePayments { get; set; } = new();
}

public class RateCalculatorViewModel
{
    public List<EstateService> Services { get; set; } = new();
    public decimal VatPercentage { get; set; } = 15m;
    public decimal OutstandingBalance { get; set; }
}
