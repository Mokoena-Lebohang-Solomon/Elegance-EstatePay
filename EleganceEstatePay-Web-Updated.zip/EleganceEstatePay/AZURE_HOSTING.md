# Azure hosting process

## Azure resources

1. Create an **Azure SQL Database** and allow connections from Azure services.
2. Create an **Azure App Service** using the Windows or Linux .NET 9 runtime.
3. In the App Service configuration, add a connection string named `DefaultConnection` with type `SQLAzure`.
4. Keep SQL credentials in Azure configuration. Do not place production credentials in `appsettings.json`.

## Prepare the database

Run `Database/schema.sql` against the Azure SQL database. For an older database, also run `Database/upgrade_remove_estate_unit.sql`.

## Publish from Visual Studio 2022

1. Open `EleganceEstatePay.sln`.
2. Right-click the web project and choose **Publish**.
3. Select **Azure**, **Azure App Service**, then the App Service created above.
4. Under Settings, confirm `Release`, `net9.0`, and the Azure SQL connection string.
5. Publish, open the HTTPS address, and immediately change the seeded demonstration passwords.

## Production checks

- Set `ASPNETCORE_ENVIRONMENT` to `Production`.
- Enable **HTTPS Only**, App Service logs, backups, Azure SQL auditing, and a custom domain/certificate when available.
- Restrict Azure SQL firewall access and use a dedicated least-privilege SQL account.
- Test resident registration, all three payment options, password changes, officer confirmation, and reports.

## Android companion application

The Android 7.0/API 24 application should not connect directly to Azure SQL. Add authenticated ASP.NET Core Web API endpoints to this same server, then let both the MVC website and Android app use the same application services and Azure SQL database.

Recommended Android baseline:

- Kotlin, minimum SDK 24, Material Components, Retrofit/OkHttp, and encrypted local token storage.
- Mirror the website roles and screens: number/password login, resident profile, calculator, individual/bulk payments, history, notifications, and reviews.
- Match the web palette and typography from `wwwroot/css/site.css` through Android color, typography, shape, and component resources.
- Never store card numbers or CVC values on the device or server. Use a PCI-compliant payment provider before accepting real card payments.

The Android application is a separate native project and is not included in this Visual Studio web solution.