using EleganceEstatePay.Models;
using Microsoft.EntityFrameworkCore;

namespace EleganceEstatePay.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<EstateService> EstateServices => Set<EstateService>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<Notification> Notifications => Set<Notification>();
    public DbSet<ServiceReview> ServiceReviews => Set<ServiceReview>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        b.Entity<AppUser>().ToTable("Users");
        b.Entity<AppUser>().HasIndex(u => u.Number).IsUnique();
        b.Entity<AppUser>().HasIndex(u => u.Email).IsUnique();

        b.Entity<Payment>()
            .HasOne(p => p.AppUser)
            .WithMany(u => u.Payments)
            .HasForeignKey(p => p.AppUserId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<Payment>()
            .HasOne(p => p.ProcessedBy)
            .WithMany()
            .HasForeignKey(p => p.ProcessedByUserId)
            .OnDelete(DeleteBehavior.NoAction);

        b.Entity<Payment>()
            .HasOne(p => p.EstateService)
            .WithMany()
            .HasForeignKey(p => p.EstateServiceId)
            .OnDelete(DeleteBehavior.Restrict);

        b.Entity<Payment>().HasIndex(p => p.Reference).IsUnique();

        b.Entity<Notification>()
            .HasOne(n => n.AppUser)
            .WithMany(u => u.Notifications)
            .HasForeignKey(n => n.AppUserId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<ServiceReview>()
            .HasOne(r => r.Resident)
            .WithMany()
            .HasForeignKey(r => r.ResidentUserId)
            .OnDelete(DeleteBehavior.NoAction);

        b.Entity<ServiceReview>()
            .HasOne(r => r.Officer)
            .WithMany()
            .HasForeignKey(r => r.OfficerUserId)
            .OnDelete(DeleteBehavior.NoAction);

        b.Entity<ServiceReview>()
            .HasOne(r => r.Payment)
            .WithMany()
            .HasForeignKey(r => r.PaymentId)
            .OnDelete(DeleteBehavior.NoAction);
    }
}
