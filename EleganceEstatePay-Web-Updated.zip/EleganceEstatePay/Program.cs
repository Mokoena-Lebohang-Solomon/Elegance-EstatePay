using EleganceEstatePay.Data;
using EleganceEstatePay.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using Microsoft.AspNetCore.Localization;
using Microsoft.Data.SqlClient;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

var configuredConnection = builder.Configuration.GetConnectionString("DefaultConnection");
if (string.IsNullOrWhiteSpace(configuredConnection))
    throw new InvalidOperationException("Configure ConnectionStrings__DefaultConnection before starting EstatePay.");

var sqlConnection = new SqlConnectionStringBuilder(configuredConnection);
if (string.IsNullOrWhiteSpace(sqlConnection.Password))
    sqlConnection.Password = builder.Configuration["Database:Password"] ?? string.Empty;
if (!sqlConnection.IntegratedSecurity && string.IsNullOrWhiteSpace(sqlConnection.Password))
    throw new InvalidOperationException("Set Database__Password (or provide a full ConnectionStrings__DefaultConnection secret) before starting EstatePay.");

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(sqlConnection.ConnectionString));

builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/Account/Logout";
        options.AccessDeniedPath = "/Account/Denied";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
        options.Cookie.Name = "EleganceEstatePay.Auth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    })
    // Bearer tokens for the JSON API (/api/*) used by mobile or external clients.
    .AddBearerToken("Bearer", options =>
    {
        options.BearerTokenExpiration = TimeSpan.FromHours(1);
        options.RefreshTokenExpiration = TimeSpan.FromDays(14);
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", p => p.RequireRole("Administrator"));
    options.AddPolicy("OfficerOnly", p => p.RequireRole("FinancialOfficer", "Administrator"));
    options.AddPolicy("ResidentOnly", p => p.RequireRole("Resident"));
});

builder.Services.AddHttpContextAccessor();

// Use '.' as the decimal separator everywhere so amounts like 450.00 from forms and
// <input type="number"> bind correctly regardless of the server's regional settings (en-ZA uses ',').
var appCulture = new CultureInfo("en-US");
CultureInfo.DefaultThreadCurrentCulture = appCulture;
CultureInfo.DefaultThreadCurrentUICulture = appCulture;

var app = builder.Build();

app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(appCulture),
    SupportedCultures = new[] { appCulture },
    SupportedUICultures = new[] { appCulture }
});

// Create the database from the EF model if it does not exist yet. No demo data is inserted.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();

    // Demo administrator / financial officer logins + standard service tariffs (idempotent).
    DemoDataSeeder.Seed(db);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// Android emulator development uses http://10.0.2.2 to reach this host. Keep that local
// bearer-token API reachable over HTTP in Development; web pages and every deployed
// environment still use HTTPS redirection. Never use the development API on an untrusted network.
if (app.Environment.IsDevelopment())
{
    app.UseWhen(context => !context.Request.Path.StartsWithSegments("/api"), branch =>
        branch.UseHttpsRedirection());
}
else
{
    app.UseHttpsRedirection();
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
