# Elegance EstatePay Android

A native Java Android client for the supplied Elegance EstatePay ASP.NET web application. The project targets Android 9 (API 28), uses bearer-token authentication, restores sessions with the API refresh token, and loads/submits records through the web application's database-backed API.

## Android project

Open this folder in Android Studio and run the `app` module on an Android emulator or device. The default API root is the supplied hosted site, `http://eleganceestatepay.runasp.net/`. For local development instead, use `http://10.0.2.2:5150/` on an emulator (`10.0.2.2` is the emulator's host-machine alias); for a physical device, use a reachable development-host URL. Configure a different root with the Gradle property `estatePayApiBaseUrl`, for example:

If the installed app reports a connection attempt to `10.0.2.2:5150`, that APK was built with the previous emulator-only API address. A physical Android phone cannot use `10.0.2.2` to reach the hosted site. Rebuild and reinstall using this project's current `app/build.gradle.kts`; Android Studio's **Build > Build Bundle(s) / APK(s) > Build APK(s)** will use the hosted URL by default. The generated debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.

```sh
./gradlew :app:assembleDebug -PestatePayApiBaseUrl=https://api.example.com/
```

The root URL must end with `/` and must not append `/api/v1`; the app calls the web app routes directly. **The Android app connects to the ASP.NET API, not directly to SQL Server.** The API/web app must be running on your development machine or deployed at a reachable URL. `db75118.public.databaseasp.net` is the database server host, not an Android API base URL. I verified the supplied site currently responds over HTTP, including `GET /api/services`; an HTTPS request from this environment failed during TLS negotiation. Therefore this build is configured for HTTP testing only. HTTP does not encrypt login credentials or bearer tokens—do not use real accounts or payment data until HTTPS is enabled on the hosted site, then switch the base URL to `https://eleganceestatepay.runasp.net/`. `Program.cs` bypasses HTTPS redirection for `/api/*` only in Development so the Android emulator can reach the local HTTP port. Never expose that development HTTP endpoint or use it on an untrusted network.

The supplied project may contain machine-specific `local.properties`; Android Studio should regenerate it for your own SDK installation. Minimum and target SDK are both API 28.

## Connect to the supplied web app

The companion API adapter is `backend-integration/MobileApiControllers.cs`. Copy it to the web project's `Controllers/Api/` folder, or use the same file already present in the updated web project. ASP.NET Core's controller discovery finds it automatically. The updated `Program.cs` enables the local Android-emulator HTTP development route while retaining HTTPS redirection for pages and production.

The mobile adapter adds safe bearer-authenticated endpoints for `/api/auth/me`; resident profile updates, review eligibility and review submission; officer payment queue/detail/confirm/flag and resident-account workflows; and administrator dashboards, residents, officers, activity, reviews, profile and service tariffs. Existing web routes continue to provide login, registration, token refresh, password changes, service listings, resident payment submissions, notifications, and reports. The controllers reuse the web app's EF database and existing user/password validation; they do not create a separate database.

Start the web app with the same database configuration as the web portal. The source config identifies the supplied SQL Server host/catalog/login but does not include the password. For local development, set it with `dotnet user-secrets set "Database:Password" "<database-password>"` from the web-project directory; for deployment, set `Database__Password` as a secret/environment variable. The full connection can alternatively be supplied through `ConnectionStrings__DefaultConnection`. The first startup uses the existing database seeder. Check the demo credentials in `Data/DemoDataSeeder.cs`; for real resident accounts, register an account through the Android sign-up screen or the web portal. Officer accounts must be authorised by an administrator before sign-in.

## Implemented screens and actions

Residents can sign in/register, see their balance and payment history, pay an individual service, choose a bulk selection or pay all services, submit EFT/bank-transfer, debit-order or card-method requests, view notifications, rate an officer who processed a payment, edit contact/bank profile fields, change password and sign out. The payment API validates card details but does not store card number/CVC or charge a card; use a PCI-compliant hosted payment provider for real card processing.

Financial officers can see the pending-payment queue, inspect a payment and the resident's account summary, confirm or flag a payment (which records processor/decision metadata and notifies the resident), search/edit/create/delete resident accounts, reset resident passwords, view their reviews and manage profile/password settings. Administrators can view dashboard metrics and recent activity, search/create/edit/suspend/delete residents, create and authorise/activate/suspend/delete financial officers, inspect activity and resident reviews, view reports, update service tariffs and manage their profile.

All list, account, payment, review, notification, tariff and report data is fetched from the API; no hard-coded sample records are used for these workflows. Access is still controlled by API role authorization, not merely by which Android screen is visible.

## Validation notes

The Java sources were compiled directly against Android and resolved dependency jars. A complete Gradle APK build is environment-dependent on Android SDK build tools, and the ASP.NET controller adapter should be built/tested with the .NET 9 SDK in Visual Studio 2022 or another .NET 9 environment. This sandbox does not include that .NET SDK. Enable HTTPS before deployment and use a proper card-payment provider before accepting real card data.
