package com.example.mohale;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Small replaceable REST client for the EstatePay ASP.NET web API. */
public final class DemoApi {
    public interface Callback { void onResult(int status, JSONObject body); void onError(Exception error); }
    private static final ExecutorService IO=Executors.newFixedThreadPool(3);
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static volatile String token="";
    private static volatile String refreshToken="";
    private static volatile boolean persistTokens=true;
    private static volatile Context appContext;
    private DemoApi(){}
    public static void init(Context context){appContext=context.getApplicationContext();android.content.SharedPreferences p=appContext.getSharedPreferences("estatepay",Context.MODE_PRIVATE);token=p.getString("accessToken","");refreshToken=p.getString("refreshToken","");}
    public static void setToken(String value){setTokens(value,refreshToken);}
    public static void setTokens(String access,String refresh){setTokens(access,refresh,true);}
    public static void setTokens(String access,String refresh,boolean persist){token=access==null?"":access;refreshToken=refresh==null?"":refresh;persistTokens=persist;if(appContext!=null){android.content.SharedPreferences.Editor e=appContext.getSharedPreferences("estatepay",Context.MODE_PRIVATE).edit();if(persist)e.putString("accessToken",token).putString("refreshToken",refreshToken);else e.remove("accessToken").remove("refreshToken");e.apply();}}
    public static void clearToken(){setTokens("","");}
    public static String getToken(){return token;}
    public static void request(String method,String path,JSONObject payload,Callback callback){
        IO.execute(()->{HttpURLConnection c=null;try{
            String base=BuildConfig.API_BASE_URL;
            if(!base.endsWith("/"))base+="/";
            c=(HttpURLConnection)new URL(base+path.replaceFirst("^/","")).openConnection();
            c.setRequestMethod(method);c.setConnectTimeout(12000);c.setReadTimeout(15000);
            c.setRequestProperty("Accept","application/json");
            String auth=token;if(!auth.isEmpty())c.setRequestProperty("Authorization","Bearer "+auth);
            if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");try(OutputStream out=c.getOutputStream()){out.write(payload.toString().getBytes(StandardCharsets.UTF_8));}}
            int code=c.getResponseCode();InputStream stream=code<400?c.getInputStream():c.getErrorStream();StringBuilder text=new StringBuilder();
            if(stream!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)text.append(line);}
            JSONObject result;
            if(text.length()==0)result=new JSONObject();else {
                String body=text.toString().trim();
                if(body.startsWith("[")){result=new JSONObject();result.put("items",new JSONArray(body));}
                else if(body.startsWith("{"))result=new JSONObject(body);
                else {result=new JSONObject();result.put("message",body);}
            }
            if(code==401&&!refreshToken.isEmpty()&&refreshAndRetry(method,path,payload,callback))return;
            JSONObject finalResult=result;MAIN.post(()->callback.onResult(code,finalResult));
        }catch(Exception e){MAIN.post(()->callback.onError(e));}finally{if(c!=null)c.disconnect();}});
    }
    private static boolean refreshAndRetry(String method,String path,JSONObject payload,Callback callback){
        try{
            String base=BuildConfig.API_BASE_URL;if(!base.endsWith("/"))base+="/";HttpURLConnection c=(HttpURLConnection)new URL(base+"api/auth/refresh").openConnection();
            c.setRequestMethod("POST");c.setConnectTimeout(10000);c.setReadTimeout(12000);c.setDoOutput(true);c.setRequestProperty("Accept","application/json");c.setRequestProperty("Content-Type","application/json; charset=utf-8");
            JSONObject body=new JSONObject();body.put("refreshToken",refreshToken);try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}
            if(c.getResponseCode()<200||c.getResponseCode()>=300){c.disconnect();clearToken();return false;}
            StringBuilder text=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)text.append(line);}c.disconnect();JSONObject tokens=new JSONObject(text.toString());setTokens(tokens.optString("accessToken",token),tokens.optString("refreshToken",refreshToken),persistTokens);
            requestWithoutRefresh(method,path,payload,callback);return true;
        }catch(Exception ignored){clearToken();return false;}
    }
    private static void requestWithoutRefresh(String method,String path,JSONObject payload,Callback callback){
        IO.execute(()->{HttpURLConnection c=null;try{String base=BuildConfig.API_BASE_URL;if(!base.endsWith("/"))base+="/";c=(HttpURLConnection)new URL(base+path.replaceFirst("^/","")).openConnection();c.setRequestMethod(method);c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("Accept","application/json");if(!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");try(OutputStream out=c.getOutputStream()){out.write(payload.toString().getBytes(StandardCharsets.UTF_8));}}int status=c.getResponseCode();InputStream stream=status<400?c.getInputStream():c.getErrorStream();StringBuilder data=new StringBuilder();if(stream!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)data.append(line);}JSONObject result=parseBody(data.toString());MAIN.post(()->callback.onResult(status,result));}catch(Exception e){MAIN.post(()->callback.onError(e));}finally{if(c!=null)c.disconnect();}});
    }
    private static JSONObject parseBody(String text)throws JSONException{if(text==null||text.trim().isEmpty())return new JSONObject();String value=text.trim();if(value.startsWith("[")){JSONObject o=new JSONObject();o.put("items",new JSONArray(value));return o;}if(value.startsWith("{"))return new JSONObject(value);JSONObject o=new JSONObject();o.put("message",value);return o;}
    /** Compatibility overload for earlier starter implementations. */
    public static void request(String method,String path,JSONObject payload,String ignoredToken,Callback callback){request(method,path,payload,callback);}
    public static JSONObject object(Object... pairs){JSONObject o=new JSONObject();try{for(int i=0;i+1<pairs.length;i+=2)o.put(String.valueOf(pairs[i]),pairs[i+1]);}catch(JSONException ignored){}return o;}
}
