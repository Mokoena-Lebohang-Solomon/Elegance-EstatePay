plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.mohale"
    compileSdk = 35
    val estatePayApiBaseUrl = (project.findProperty("estatePayApiBaseUrl") as String?) ?: "http://eleganceestatepay.runasp.net/"

    defaultConfig {
        applicationId = "com.example.mohale"
        minSdk = 28
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "API_BASE_URL", "\"${estatePayApiBaseUrl}\"")

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures { buildConfig = true }
}

dependencies {

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}
