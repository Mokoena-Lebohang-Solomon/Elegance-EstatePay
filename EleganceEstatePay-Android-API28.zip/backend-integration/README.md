# ASP.NET web API integration

The Android app uses the supplied EstatePay web application's database and authentication. To apply the API additions to the original Visual Studio project:

1. Copy `MobileApiControllers.cs` to `EleganceEstatePay/Controllers/Api/`.
2. Replace `EleganceEstatePay/Program.cs` with the included version, or copy only the development HTTP API middleware block if you have made unrelated Program.cs changes. The block bypasses HTTPS redirection for `/api/*` only in `Development`; production still redirects to HTTPS.
3. Set the SQL password outside source control. For local development, run `dotnet user-secrets set "Database:Password" "<database-password>"` from the web project directory; for deployment, set `Database__Password` as a secret/environment variable. The complete `ConnectionStrings__DefaultConnection` environment variable can also override the non-secret host/database/user settings.
4. The Android app project defaults to the hosted API root `http://eleganceestatepay.runasp.net/`. Use `http://10.0.2.2:5150/` only for a local ASP.NET server accessed from an Android emulator; on a physical device, `10.0.2.2` is not the host computer or the public web app.
5. Build the ASP.NET web app with the .NET 9 SDK / Visual Studio 2022 before running the Android client.

The API extension controller is auto-discovered; no new NuGet packages, database tables or `Program.cs` service registrations are required. It reuses the existing EF entities, SQL database, authentication scheme, authorization roles and password hasher. Do not expose the HTTP Development endpoint beyond a trusted local test environment.
